# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.6.35)
# Database: craft_db
# Generation Time: 2017-10-02 15:19:06 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table craft_assetfiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetfiles`;

CREATE TABLE `craft_assetfiles` (
  `id` int(11) NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetfiles_filename_folderId_unq_idx` (`filename`,`folderId`),
  KEY `craft_assetfiles_sourceId_fk` (`sourceId`),
  KEY `craft_assetfiles_folderId_fk` (`folderId`),
  CONSTRAINT `craft_assetfiles_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `craft_assetfolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfiles_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfiles_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_assetfiles` WRITE;
/*!40000 ALTER TABLE `craft_assetfiles` DISABLE KEYS */;

INSERT INTO `craft_assetfiles` (`id`, `sourceId`, `folderId`, `filename`, `kind`, `width`, `height`, `size`, `dateModified`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(5,1,1,'60Qatgr.jpg','image',706,720,45216,'2017-09-12 20:42:47','2017-09-12 20:42:47','2017-09-12 20:42:47','7846a89d-2cea-41bb-b694-c61f8bcfeba4'),
	(7,1,1,'zbWNxoR.mp4','video',NULL,NULL,3850503,'2017-09-13 09:35:04','2017-09-13 09:35:05','2017-09-13 09:35:05','d2ccc2a8-4d84-4a15-a588-e3f8365520ef'),
	(10,1,1,'katie-hetland-175855.jpg','image',6000,4000,543602,'2017-09-13 18:53:53','2017-09-13 18:53:55','2017-09-13 18:53:55','52f7cdfb-e173-40ca-ab4c-239c7c379aca'),
	(11,1,1,'2017-01-25-1485324352-6613706-GTYwomensmarchwashington4jt170121_12x5_1600.jpg','image',1600,668,262645,'2017-09-14 00:39:15','2017-09-14 00:39:15','2017-09-14 00:39:15','fe4bf02d-aed8-4847-9213-5b24d522edc4'),
	(16,1,1,'arrests3.jpg','image',632,842,316289,'2017-09-14 19:10:01','2017-09-14 19:10:01','2017-09-14 19:10:01','8d347ff2-cead-43e9-9592-b0c2e46c2121'),
	(20,1,1,'arrests4.jpg','image',426,671,314960,'2017-09-14 19:23:00','2017-09-14 19:23:01','2017-09-14 19:23:01','dedafbea-5e3f-4b1a-b1bc-e6a0fd7a5fe8'),
	(21,1,1,'arrests5.jpg','image',753,1075,714796,'2017-09-14 19:23:01','2017-09-14 19:23:01','2017-09-14 19:23:01','39e78383-e802-4f4d-be26-153c00c24dd3'),
	(22,1,1,'arrests4_170914_192902.jpg','image',753,702,250026,'2017-09-14 19:29:02','2017-09-14 19:29:03','2017-09-14 19:29:03','9e0b0e0e-d04e-4a13-90af-447e12fef4ef'),
	(24,1,1,'arrests1.jpg','image',1549,717,716700,'2017-09-14 19:35:23','2017-09-14 19:35:24','2017-09-14 19:35:24','462f4532-43d6-4efe-a63b-dd4864a3e28b'),
	(25,1,1,'amendment1.jpg','image',1361,862,747904,'2017-09-14 20:29:46','2017-09-14 20:29:46','2017-09-14 20:29:46','c33f769e-6c6c-4b30-b3dd-25f7f974cbf8'),
	(26,1,1,'amendment2.jpg','image',1301,689,489942,'2017-09-14 20:29:47','2017-09-14 20:29:47','2017-09-14 20:29:47','be8b2d85-a48a-4d43-99d5-465a6dd809ab'),
	(27,1,1,'amendment3.jpg','image',1041,844,808474,'2017-09-14 20:29:47','2017-09-14 20:29:47','2017-09-14 20:29:47','43789c1d-3346-401c-8109-00b5db7d51c6'),
	(28,1,1,'amendment4.jpg','image',1616,994,1000844,'2017-09-14 20:29:48','2017-09-14 20:29:48','2017-09-14 20:29:48','5481c787-fd01-4e69-8ee6-af1da284347a'),
	(29,1,1,'amendment5.jpg','image',1362,803,503775,'2017-09-14 20:29:48','2017-09-14 20:29:48','2017-09-14 20:29:48','95a2f4df-77ee-4a86-baee-55a0b68ad3e3'),
	(30,1,1,'amendment6.jpg','image',715,915,471473,'2017-09-14 20:29:48','2017-09-14 20:29:49','2017-09-14 20:29:49','6f1941c0-e76f-4370-9bef-d5b4ed6fe6a6'),
	(37,1,1,'terror1.jpg','image',1293,718,795581,'2017-09-14 20:48:36','2017-09-14 20:48:36','2017-09-14 20:48:36','ab233e57-045c-427a-949e-b69681865b44'),
	(38,1,1,'terror2.jpg','image',784,707,162272,'2017-09-14 20:48:36','2017-09-14 20:48:36','2017-09-14 20:48:36','604ac783-fe6f-45a7-ab94-faaab40c0cb3'),
	(39,1,1,'terror3.jpg','image',725,922,474677,'2017-09-14 20:48:37','2017-09-14 20:48:37','2017-09-14 20:48:37','4748adf0-c490-4f43-b5c3-2bd98a4f6dd7'),
	(40,1,1,'terror4.jpg','image',858,743,346780,'2017-09-14 20:48:37','2017-09-14 20:48:37','2017-09-14 20:48:37','657db206-df06-4998-99c0-4009115aefd4'),
	(46,1,1,'movement1.jpg','image',1153,780,645681,'2017-09-14 21:11:07','2017-09-14 21:11:07','2017-09-14 21:11:07','a2f2f637-8821-43b0-bfd2-06a09c52cb63'),
	(47,1,1,'movement2.jpg','image',522,692,252283,'2017-09-14 21:11:07','2017-09-14 21:11:07','2017-09-14 21:11:07','74ca5ba7-488e-4526-9abb-ccbd3dcef782'),
	(48,1,1,'movement3.jpg','image',449,558,219446,'2017-09-14 21:11:08','2017-09-14 21:11:08','2017-09-14 21:11:08','f5393a0b-f37e-40d9-b4ec-8e0897bd761a'),
	(49,1,1,'movement4.jpg','image',1495,824,690142,'2017-09-14 21:11:08','2017-09-14 21:11:08','2017-09-14 21:11:08','e1649fba-3b9b-492a-bcf7-29a41866dfc1'),
	(50,1,1,'movement5.jpg','image',1413,769,812492,'2017-09-14 21:11:08','2017-09-14 21:11:09','2017-09-14 21:11:09','2bf23d0c-f465-47c4-9c78-4d77d7b0b951'),
	(51,1,1,'dude.jpg','image',994,850,225122,'2017-09-14 21:13:14','2017-09-14 21:13:14','2017-09-14 21:13:14','62249704-6e09-4beb-a0ba-9e9f57537373'),
	(58,1,1,'home3.png','image',326,891,1164690,'2017-09-15 19:26:59','2017-09-15 19:26:59','2017-09-15 19:26:59','e4b36f86-9156-423f-9457-6d87205d0ecb'),
	(59,1,1,'logo-twitter.png','image',48,48,892,'2017-09-18 13:32:59','2017-09-18 12:43:54','2017-09-18 13:33:05','c4e59b66-47dc-4c62-93d2-55642245cd1a'),
	(61,1,1,'logo-fb-simple.png','image',48,48,399,'2017-09-18 13:32:58','2017-09-18 13:32:58','2017-09-18 13:32:58','56c7f53a-4428-4cbf-ae58-85426c0a2a87'),
	(62,1,1,'logo-instagram.png','image',48,48,1067,'2017-09-18 13:32:58','2017-09-18 13:32:58','2017-09-18 13:32:58','416464f3-b606-44fe-9962-df809441fd73'),
	(63,1,1,'logo-medium.png','image',48,48,685,'2017-09-18 13:32:58','2017-09-18 13:32:59','2017-09-18 13:32:59','2958e9ee-864b-44ab-95ad-a61be811618f'),
	(65,1,1,'logo-viget.png','image',136,47,12233,'2017-09-18 13:32:59','2017-09-18 13:32:59','2017-09-18 13:32:59','b1af903b-f397-497c-aa3b-3ef205b9f91e'),
	(66,1,1,'logo-alt-fb-simple.png','image',48,48,486,'2017-09-18 13:33:55','2017-09-18 13:33:55','2017-09-18 13:33:55','646da184-feea-48cc-88ab-45a8ed948688'),
	(67,1,1,'logo-alt-instagram.png','image',48,48,1423,'2017-09-18 13:33:55','2017-09-18 13:33:55','2017-09-18 13:33:55','c5de79aa-b33c-4de7-992c-1cce89a105bb'),
	(68,1,1,'logo-alt-medium.png','image',48,48,805,'2017-09-18 13:33:59','2017-09-18 13:33:59','2017-09-18 13:33:59','dce7ba95-e0af-4381-ae2d-fceb642da138'),
	(69,1,1,'logo-alt-twitter.png','image',48,48,1073,'2017-09-18 13:34:01','2017-09-18 13:34:01','2017-09-18 13:34:01','93782647-f3d8-46ba-aac3-2479de7086d3'),
	(70,1,1,'arrests2.png','image',1660,917,6099701,'2017-09-20 14:05:38','2017-09-20 13:59:58','2017-09-20 14:05:41','c14bc854-fe5f-403e-b340-4418b0cc5896'),
	(71,1,1,'arrests5.png','image',753,1075,1012331,'2017-09-21 13:55:07','2017-09-21 13:55:07','2017-09-21 13:55:07','2f82b361-094f-4e90-b3ab-7bb2a9f88fce'),
	(72,1,1,'arrests4.png','image',753,702,2118605,'2017-09-21 13:59:30','2017-09-21 13:59:30','2017-09-21 13:59:30','0d1fe6f7-0d5c-4715-bbfe-0e82c9e10b1a'),
	(73,1,1,'arrests3.png','image',426,670,1144251,'2017-09-21 15:55:28','2017-09-21 15:55:28','2017-09-21 15:55:28','de99235e-2451-45a4-9de4-7d064cb147fd'),
	(74,1,1,'arrests6.png','image',656,731,1922036,'2017-09-21 15:55:29','2017-09-21 15:55:29','2017-09-21 15:55:29','fa7a27b5-afc3-40f4-982d-52ea620632be'),
	(75,1,1,'arrests1.png','image',1549,717,4450491,'2017-09-21 15:57:23','2017-09-21 15:57:23','2017-09-21 15:57:23','894b923c-7665-48ca-8ae4-a914cb886964');

/*!40000 ALTER TABLE `craft_assetfiles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_assetfolders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetfolders`;

CREATE TABLE `craft_assetfolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetfolders_name_parentId_sourceId_unq_idx` (`name`,`parentId`,`sourceId`),
  KEY `craft_assetfolders_parentId_fk` (`parentId`),
  KEY `craft_assetfolders_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_assetfolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_assetfolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfolders_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_assetfolders` WRITE;
/*!40000 ALTER TABLE `craft_assetfolders` DISABLE KEYS */;

INSERT INTO `craft_assetfolders` (`id`, `parentId`, `sourceId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,1,'localstorage','','2017-09-12 20:20:03','2017-09-12 20:20:03','86540806-c48e-47b5-a424-230bada27b35');

/*!40000 ALTER TABLE `craft_assetfolders` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_assetindexdata
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetindexdata`;

CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceId` int(10) NOT NULL,
  `offset` int(10) NOT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recordId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetindexdata_sessionId_sourceId_offset_unq_idx` (`sessionId`,`sourceId`,`offset`),
  KEY `craft_assetindexdata_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_assetindexdata_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_assetsources
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetsources`;

CREATE TABLE `craft_assetsources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetsources_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assetsources_handle_unq_idx` (`handle`),
  KEY `craft_assetsources_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_assetsources_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_assetsources` WRITE;
/*!40000 ALTER TABLE `craft_assetsources` DISABLE KEYS */;

INSERT INTO `craft_assetsources` (`id`, `name`, `handle`, `type`, `settings`, `sortOrder`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'localstorage','localstorage','Local','{\"path\":\"localstorage\\/\",\"publicURLs\":\"1\",\"url\":\"{baseUrl}localstorage\\/\"}',1,20,'2017-09-12 20:20:03','2017-09-13 09:34:33','f55c5da4-554e-4a6f-8eff-b0940e0a9220');

/*!40000 ALTER TABLE `craft_assetsources` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_assettransformindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransformindex`;

CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fileId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT NULL,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assettransformindex_sourceId_fileId_location_idx` (`sourceId`,`fileId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_assettransforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransforms`;

CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `height` int(10) DEFAULT NULL,
  `width` int(10) DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int(10) DEFAULT NULL,
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categories`;

CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categories_groupId_fk` (`groupId`),
  CONSTRAINT `craft_categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_categorygroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups`;

CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_categorygroups_handle_unq_idx` (`handle`),
  KEY `craft_categorygroups_structureId_fk` (`structureId`),
  KEY `craft_categorygroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_categorygroups_i18n
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups_i18n`;

CREATE TABLE `craft_categorygroups_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `urlFormat` text COLLATE utf8_unicode_ci,
  `nestedUrlFormat` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_i18n_groupId_locale_unq_idx` (`groupId`,`locale`),
  KEY `craft_categorygroups_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_categorygroups_i18n_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categorygroups_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_content`;

CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_body` text COLLATE utf8_unicode_ci,
  `field_titleText` text COLLATE utf8_unicode_ci,
  `field_colorPicker` char(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_date` text COLLATE utf8_unicode_ci,
  `field_leadIn` text COLLATE utf8_unicode_ci,
  `field_pageTitle` text COLLATE utf8_unicode_ci,
  `field_description` text COLLATE utf8_unicode_ci,
  `field_siteDescription` text COLLATE utf8_unicode_ci,
  `field_whoDescription` text COLLATE utf8_unicode_ci,
  `field_campaignDescription` text COLLATE utf8_unicode_ci,
  `field_social1` text COLLATE utf8_unicode_ci,
  `field_social2` text COLLATE utf8_unicode_ci,
  `field_social3` text COLLATE utf8_unicode_ci,
  `field_social4` text COLLATE utf8_unicode_ci,
  `field_sentinel` text COLLATE utf8_unicode_ci,
  `field_bio` text COLLATE utf8_unicode_ci,
  `field_colorSwatch` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_content_elementId_locale_unq_idx` (`elementId`,`locale`),
  KEY `craft_content_title_idx` (`title`),
  KEY `craft_content_locale_fk` (`locale`),
  CONSTRAINT `craft_content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_content_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;

INSERT INTO `craft_content` (`id`, `elementId`, `locale`, `title`, `field_body`, `field_titleText`, `field_colorPicker`, `field_date`, `field_leadIn`, `field_pageTitle`, `field_description`, `field_siteDescription`, `field_whoDescription`, `field_campaignDescription`, `field_social1`, `field_social2`, `field_social3`, `field_social4`, `field_sentinel`, `field_bio`, `field_colorSwatch`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-11 21:31:08','2017-10-02 15:17:04','363f45ff-940f-4f8b-bdf3-86d7a57e855d'),
	(2,2,'en_us','Test','<p>It’s true, this site doesn’t have a whole lot of content yet, but don’t worry. Our web developers have just installed the CMS, and they’re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.</p>',NULL,'#ac7e49',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-11 21:31:12','2017-09-18 12:40:45','20a9e563-82f6-4bcc-9f09-a3f9b257c7f7'),
	(4,4,'en_us',NULL,NULL,'Twitter',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Medium','Twitter','Facebook','Instagram',NULL,NULL,NULL,'2017-09-12 18:26:20','2017-09-18 13:35:33','b33a729e-a4c6-4986-bd99-e457de4570be'),
	(5,5,'en_us','60 Qatgr',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-12 20:42:47','2017-09-12 20:42:47','2f6234e2-ba1e-4eb0-a8a7-cc96d15aa518'),
	(7,7,'en_us','Zb Wnxo R',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-13 09:35:05','2017-09-13 09:35:05','a4c149bb-35af-46f1-b49e-5ee5be7778d9'),
	(8,8,'en_us','The Beginning of The Movement',NULL,'The Movement',NULL,'1848-1917','The Beginning of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-13 17:22:55','2017-09-14 21:16:08','ccdfb78f-1a05-44bf-8002-ad206cef8373'),
	(9,10,'en_us','Katie Hetland 175855',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-13 18:53:54','2017-09-13 18:53:54','6e3ac9c9-ffc9-4feb-903d-ead69a854e8b'),
	(10,11,'en_us','2017 01 25 1485324352 6613706 Gtywomensmarchwashington4Jt170121 12X5 1600',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 00:39:15','2017-09-14 00:39:15','0eb5229f-90e1-4b71-8e08-7e9a4e90068c'),
	(11,12,'en_us','The Arrests',NULL,'Arrests',NULL,'1917-1919','The',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label\":\"darkTurqouise\",\"color\":\"#024c64\",\"__model__\":\"Craft\\\\ColorSwatchesModel\"}','2017-09-14 00:39:27','2017-09-25 17:32:43','c71f2617-fb53-4bbf-b45f-53a2c8db337b'),
	(13,16,'en_us','Arrests3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:10:01','2017-09-14 19:10:01','77a4211a-55ee-411d-b947-f07933690277'),
	(14,20,'en_us','Arrests4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:23:01','2017-09-14 19:23:01','25c3740a-127e-4d53-9c3b-f6373f04e5c3'),
	(15,21,'en_us','Arrests5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:23:01','2017-09-14 19:23:01','585ca6e8-8d4c-4ebc-95f2-d0ced1ec0432'),
	(16,22,'en_us','Arrests4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:29:03','2017-09-14 19:29:03','9d8dd0a1-9b93-4dd7-99b5-18ccc88e680d'),
	(17,24,'en_us','Arrests1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:35:24','2017-09-14 19:35:24','f5936be5-5df1-4aef-a42e-9639a400e167'),
	(18,25,'en_us','Amendment1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:29:46','2017-09-14 20:29:46','23e88f94-885f-47ad-978b-33475cf7a7a1'),
	(19,26,'en_us','Amendment2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:29:47','2017-09-14 20:29:47','8ece24f7-64da-44ec-99b2-b19b97459da5'),
	(20,27,'en_us','Amendment3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:29:47','2017-09-14 20:29:47','a3dab369-9677-4ef8-9ee4-2065c0208b9a'),
	(21,28,'en_us','Amendment4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:29:48','2017-09-14 20:29:48','165eb6e6-ecc2-43b0-915a-794f3dbdd110'),
	(22,29,'en_us','Amendment5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:29:48','2017-09-14 20:29:48','11b14f39-94e5-42cc-abf8-539889aaa97a'),
	(23,30,'en_us','Amendment6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:29:49','2017-09-14 20:29:49','a13a5f5a-541f-4404-b2b6-7523addcfbd5'),
	(24,31,'en_us','Woodrow Wilson & The 19th Amendment',NULL,'The 19th Amendment',NULL,'August 26, 1920','Woodrow Wilson &',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:33:33','2017-09-14 20:42:05','b4be1dd8-7860-4218-a612-31580e5eda4a'),
	(25,37,'en_us','Terror1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:48:36','2017-09-14 20:48:36','a541ca34-a28c-4cd5-bd9f-53abd7d6729a'),
	(26,38,'en_us','Terror2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:48:36','2017-09-14 20:48:36','e0bf1c8d-6241-449b-b3c0-d550701ba2c4'),
	(27,39,'en_us','Terror3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:48:37','2017-09-14 20:48:37','b631963f-81ab-444c-8e44-0ea5f2776dfd'),
	(28,40,'en_us','Terror4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:48:37','2017-09-14 20:48:37','a5e603ff-d2c5-477c-8ffc-03704870c2a7'),
	(29,41,'en_us','The Night of Terror',NULL,'Night Of Terror',NULL,'Nov. 14, 1917','The ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:55:41','2017-09-18 14:02:07','09e03604-2a74-4f50-a746-d17ccb086d08'),
	(30,46,'en_us','Movement1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:11:07','2017-09-14 21:11:07','8c1ffc76-98e8-4676-aa30-8d0a30e51c9f'),
	(31,47,'en_us','Movement2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:11:07','2017-09-14 21:11:07','fea7a571-0d25-4f40-9832-fb56f6af40ce'),
	(32,48,'en_us','Movement3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:11:08','2017-09-14 21:11:08','e6c7e468-ca6b-47cd-b0e7-e922128c688e'),
	(33,49,'en_us','Movement4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:11:08','2017-09-14 21:11:08','a4bf0ca3-5f4f-4796-a0b3-6f2087ee8480'),
	(34,50,'en_us','Movement5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:11:09','2017-09-14 21:11:09','1b734be2-4cb2-4ff0-a745-bcc3575f7cfb'),
	(35,51,'en_us','Dude',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:13:14','2017-09-14 21:13:14','610c03ff-b4fb-4c33-a61e-9471c29347b5'),
	(36,56,'en_us','The Silent Sentinels',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-15 13:49:43','2017-09-15 13:49:43','83c9e35d-409d-42aa-80a2-087b5f7744df'),
	(37,57,'en_us','Sentinel Bio',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-15 13:56:49','2017-09-15 13:56:49','4841990c-7a50-4174-8f77-efa0cbec6083'),
	(38,58,'en_us','Home3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-15 19:26:59','2017-09-15 19:26:59','d6609964-9ec4-4879-86fb-825ebb37898a'),
	(39,59,'en_us','Logo Twitter',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 12:43:54','2017-09-18 13:33:05','532eee6d-1897-447f-927e-d28fe42c8b95'),
	(41,61,'en_us','Logo Fb Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:32:58','2017-09-18 13:32:58','f4701734-41d7-4a94-a52f-765205fb8876'),
	(42,62,'en_us','Logo Instagram',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:32:58','2017-09-18 13:32:58','1a8d7161-9c53-40e4-bdfa-ee0262dedc11'),
	(43,63,'en_us','Logo Medium',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:32:59','2017-09-18 13:32:59','58c70325-ce04-49f6-b7e2-3371762dbb6c'),
	(45,65,'en_us','Logo Viget',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:32:59','2017-09-18 13:32:59','a0dd5730-b907-4fe6-a9b3-498f82a95d17'),
	(46,66,'en_us','Logo Alt Fb Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:33:55','2017-09-18 13:33:55','78157fb5-d562-4f74-aee9-35751466e449'),
	(47,67,'en_us','Logo Alt Instagram',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:33:55','2017-09-18 13:33:55','e6b26271-5641-4fa3-b02c-6772a25952b8'),
	(48,68,'en_us','Logo Alt Medium',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:33:59','2017-09-18 13:33:59','6ec07295-b94b-4bce-9c20-96a6282b887a'),
	(49,69,'en_us','Logo Alt Twitter',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-18 13:34:01','2017-09-18 13:34:01','4b1c180e-b891-443d-b0cd-811dbaa44b4d'),
	(50,70,'en_us','Arrests2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-20 13:59:58','2017-09-20 14:05:41','5727a401-8fbb-4f4f-bc95-017500b0cede'),
	(51,71,'en_us','Arrests5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-21 13:55:07','2017-09-21 13:55:07','39548766-a2ce-496b-8b8e-f5fdf24635f7'),
	(52,72,'en_us','Arrests4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-21 13:59:30','2017-09-21 13:59:30','c7a77324-832a-4340-a570-7c1247a648d5'),
	(53,73,'en_us','Arrests3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-21 15:55:28','2017-09-21 15:55:28','ce259966-5e9e-47c7-a8ec-e6aac36455bb'),
	(54,74,'en_us','Arrests6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-21 15:55:29','2017-09-21 15:55:29','79ab3d80-ff09-48c5-b7cb-05d54d9b80f9'),
	(55,75,'en_us','Arrests1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-21 15:57:23','2017-09-21 15:57:23','e20198cf-6717-499e-a104-511625942617');

/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_deprecationerrors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_deprecationerrors`;

CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint(6) unsigned NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateLine` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `traces` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_elementindexsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elementindexsettings`;

CREATE TABLE `craft_elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_elements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements`;

CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_elements_type_idx` (`type`),
  KEY `craft_elements_enabled_idx` (`enabled`),
  KEY `craft_elements_archived_dateCreated_idx` (`archived`,`dateCreated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;

INSERT INTO `craft_elements` (`id`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'User',1,0,'2017-09-11 21:31:08','2017-10-02 15:17:04','bd94d708-37b8-497b-862a-7bb0995a4656'),
	(2,'Entry',1,0,'2017-09-11 21:31:12','2017-09-18 12:40:45','a358d5d2-3bb8-47b1-9c75-1d6fb9ec2469'),
	(4,'GlobalSet',1,0,'2017-09-12 18:26:20','2017-09-18 13:35:33','3f77a4ec-9ece-41e1-b3c5-a192b6dcb456'),
	(5,'Asset',1,0,'2017-09-12 20:42:47','2017-09-12 20:42:47','ba3ddc43-72ad-4b40-9ee1-81ec087445a3'),
	(7,'Asset',1,0,'2017-09-13 09:35:05','2017-09-13 09:35:05','f559fd10-d0f6-4f9c-9c0a-c554cc6493bc'),
	(8,'Entry',1,0,'2017-09-13 17:22:55','2017-09-14 21:16:08','fa86e4ec-c206-48f0-a510-05081e668751'),
	(9,'MatrixBlock',1,0,'2017-09-13 17:22:55','2017-09-14 21:16:08','3896962f-19ef-48ac-a4ed-43c113628907'),
	(10,'Asset',1,0,'2017-09-13 18:53:54','2017-09-13 18:53:54','67568e92-4cff-49f0-8177-c66d82c6fd33'),
	(11,'Asset',1,0,'2017-09-14 00:39:15','2017-09-14 00:39:15','08f3faf6-12f8-4866-9d88-75fe4d16c086'),
	(12,'Entry',1,0,'2017-09-14 00:39:27','2017-09-25 17:32:43','f510d44a-633a-48bb-adbb-4f05af9f2248'),
	(13,'MatrixBlock',1,0,'2017-09-14 00:39:27','2017-09-25 17:32:43','44abe774-3b17-4dfd-b950-1d2d6e2e2733'),
	(16,'Asset',1,0,'2017-09-14 19:10:01','2017-09-14 19:10:01','270f52a1-4147-4da2-a9cd-61df365137f0'),
	(17,'MatrixBlock',1,0,'2017-09-14 19:18:00','2017-09-25 17:32:43','f013c5e8-332c-4cf8-8170-ad9a527261b3'),
	(18,'MatrixBlock',1,0,'2017-09-14 19:18:00','2017-09-25 17:32:43','6b4af107-5376-47d7-be66-69b6b5e08ef7'),
	(19,'MatrixBlock',1,0,'2017-09-14 19:18:00','2017-09-25 17:32:43','a4dc55df-78fd-4d97-b6f7-95250e5ff13c'),
	(20,'Asset',1,0,'2017-09-14 19:23:01','2017-09-14 19:23:01','f39fa28f-549f-4e51-a6bb-fa0093f6c4c4'),
	(21,'Asset',1,0,'2017-09-14 19:23:01','2017-09-14 19:23:01','ad56f6ba-7b39-4cc5-99d1-ea2fae47c912'),
	(22,'Asset',1,0,'2017-09-14 19:29:02','2017-09-14 19:29:02','243e0ce7-7914-4515-b5ef-4e1621a40213'),
	(23,'MatrixBlock',1,0,'2017-09-14 19:31:08','2017-09-25 17:32:43','10b7bafa-aaeb-4042-85fa-df6153427169'),
	(24,'Asset',1,0,'2017-09-14 19:35:24','2017-09-14 19:35:24','623890c3-27e4-49e5-85c0-52e0e2eb78b5'),
	(25,'Asset',1,0,'2017-09-14 20:29:46','2017-09-14 20:29:46','47caf929-33cb-4d1f-8730-fec15e906681'),
	(26,'Asset',1,0,'2017-09-14 20:29:47','2017-09-14 20:29:47','a6883546-6a0b-4f88-b60b-9d36f7f76cd3'),
	(27,'Asset',1,0,'2017-09-14 20:29:47','2017-09-14 20:29:47','75d92e9a-7bf4-401a-8501-572cc67810a6'),
	(28,'Asset',1,0,'2017-09-14 20:29:48','2017-09-14 20:29:48','76e5067b-1424-4b02-9d3a-44b3b2b054ca'),
	(29,'Asset',1,0,'2017-09-14 20:29:48','2017-09-14 20:29:48','3fa6b0e2-0502-4daa-8162-2e2e30ebac75'),
	(30,'Asset',1,0,'2017-09-14 20:29:49','2017-09-14 20:29:49','36ca4df9-d0cf-4f99-a9ca-2f96ac92ecd7'),
	(31,'Entry',1,0,'2017-09-14 20:33:33','2017-09-14 20:42:05','31d434bd-3e7d-4e6d-a241-7fb5f8cb9987'),
	(32,'MatrixBlock',1,0,'2017-09-14 20:33:33','2017-09-14 20:42:05','ee960ba2-bef1-43f4-8c7e-03344b8c6686'),
	(33,'MatrixBlock',1,0,'2017-09-14 20:42:05','2017-09-14 20:42:05','ad0d4669-64b2-4047-9f87-095c818b4197'),
	(34,'MatrixBlock',1,0,'2017-09-14 20:42:06','2017-09-14 20:42:06','2339eaef-b539-425e-b659-9bf8af8ac34c'),
	(35,'MatrixBlock',1,0,'2017-09-14 20:42:06','2017-09-14 20:42:06','6886335c-61e2-492c-90e8-e22c6f885dac'),
	(36,'MatrixBlock',1,0,'2017-09-14 20:42:06','2017-09-14 20:42:06','cfad880b-41ad-4972-b0d6-9590562845cd'),
	(37,'Asset',1,0,'2017-09-14 20:48:36','2017-09-14 20:48:36','3a395322-46a1-4e29-a5e2-9af9bdcca3bf'),
	(38,'Asset',1,0,'2017-09-14 20:48:36','2017-09-14 20:48:36','5c641335-3d62-43cb-90ad-8cc337a03668'),
	(39,'Asset',1,0,'2017-09-14 20:48:37','2017-09-14 20:48:37','a0e29976-d88e-4630-836a-ed0f1917dc42'),
	(40,'Asset',1,0,'2017-09-14 20:48:37','2017-09-14 20:48:37','de10df94-04e6-4a3d-bc56-8e8c6b2bb07f'),
	(41,'Entry',1,0,'2017-09-14 20:55:41','2017-09-18 14:02:07','bc0c02de-76f5-447e-b257-8ca76cb1db72'),
	(42,'MatrixBlock',1,0,'2017-09-14 20:55:41','2017-09-18 14:02:08','51c2b41e-f506-49bc-9ecd-89b96168fe36'),
	(43,'MatrixBlock',1,0,'2017-09-14 20:55:42','2017-09-18 14:02:08','32991f89-cf84-4a9a-a6b2-67ef8ec225ba'),
	(44,'MatrixBlock',1,0,'2017-09-14 20:55:42','2017-09-18 14:02:08','c525e6f2-8666-4b6e-a4ca-112176039412'),
	(45,'MatrixBlock',1,0,'2017-09-14 20:55:42','2017-09-18 14:02:08','67fe2c90-fe59-48e1-93c7-6e502f8d0b2d'),
	(46,'Asset',1,0,'2017-09-14 21:11:07','2017-09-14 21:11:07','d5c4c06b-7802-48e9-baab-558bc7afb13d'),
	(47,'Asset',1,0,'2017-09-14 21:11:07','2017-09-14 21:11:07','2b7762fe-0653-4c35-aae6-998ba3e34dca'),
	(48,'Asset',1,0,'2017-09-14 21:11:08','2017-09-14 21:11:08','296a00df-5f10-4452-a48b-9cac7fde0152'),
	(49,'Asset',1,0,'2017-09-14 21:11:08','2017-09-14 21:11:08','0f7cc277-b0aa-4e66-8802-6db0bf4d9929'),
	(50,'Asset',1,0,'2017-09-14 21:11:09','2017-09-14 21:11:09','dabe677e-43d6-416a-80d8-d0ad4e4e81a5'),
	(51,'Asset',1,0,'2017-09-14 21:13:14','2017-09-14 21:13:14','edebcfed-b6a2-4bee-9188-2fe0751d563f'),
	(52,'MatrixBlock',1,0,'2017-09-14 21:16:08','2017-09-14 21:16:08','949e108d-0460-4e1d-a0a8-4dbf33b46ade'),
	(53,'MatrixBlock',1,0,'2017-09-14 21:16:08','2017-09-14 21:16:08','f116f29b-01ef-4cd6-accc-27b15817f9e8'),
	(54,'MatrixBlock',1,0,'2017-09-14 21:16:08','2017-09-14 21:16:08','9cb5047e-a0ee-487c-a139-ecfd447d0160'),
	(55,'MatrixBlock',1,0,'2017-09-14 21:16:08','2017-09-14 21:16:08','bf585970-d209-4f84-b118-fd1e4a09525a'),
	(56,'Entry',1,0,'2017-09-15 13:49:43','2017-09-15 13:49:43','32f76788-970b-43b7-8470-cfb93f522312'),
	(57,'Entry',1,0,'2017-09-15 13:56:49','2017-09-15 13:56:49','416c9758-b994-432d-9281-6dfe4b433fb7'),
	(58,'Asset',1,0,'2017-09-15 19:26:59','2017-09-15 19:26:59','06c2f509-a2fe-4263-85e9-90da61bd991e'),
	(59,'Asset',1,0,'2017-09-18 12:43:54','2017-09-18 13:33:05','bebf9679-460f-4bc7-881b-c69174c13c17'),
	(61,'Asset',1,0,'2017-09-18 13:32:58','2017-09-18 13:32:58','727179ba-8964-45e0-a1ee-c021d440b98a'),
	(62,'Asset',1,0,'2017-09-18 13:32:58','2017-09-18 13:32:58','03175544-eb5f-478a-934d-26cbd4e85ae7'),
	(63,'Asset',1,0,'2017-09-18 13:32:59','2017-09-18 13:32:59','b6fb21f5-4027-47de-82df-cf0d5c80e9de'),
	(65,'Asset',1,0,'2017-09-18 13:32:59','2017-09-18 13:32:59','45f7bae3-5f85-41ba-8f1d-c664b498c4dc'),
	(66,'Asset',1,0,'2017-09-18 13:33:55','2017-09-18 13:33:55','352484dd-be40-4882-8b43-6f4bedfaa4b1'),
	(67,'Asset',1,0,'2017-09-18 13:33:55','2017-09-18 13:33:55','f3964375-5dfe-44c9-8017-11747062c7ce'),
	(68,'Asset',1,0,'2017-09-18 13:33:59','2017-09-18 13:33:59','c224bbe5-ac35-4836-ade6-fa9860b73668'),
	(69,'Asset',1,0,'2017-09-18 13:34:01','2017-09-18 13:34:01','9fb7dfae-f830-4da5-b2d2-4d075eaab9c7'),
	(70,'Asset',1,0,'2017-09-20 13:59:58','2017-09-20 14:05:41','37066509-2c48-4182-a153-564e991cc317'),
	(71,'Asset',1,0,'2017-09-21 13:55:07','2017-09-21 13:55:07','f6bb7aee-66f4-448c-99a1-407c8baff2de'),
	(72,'Asset',1,0,'2017-09-21 13:59:30','2017-09-21 13:59:30','d41b53d6-dc82-4446-9013-5cd3555e4f8e'),
	(73,'Asset',1,0,'2017-09-21 15:55:28','2017-09-21 15:55:28','23a177f9-6d98-4b98-8bce-863fa26df62f'),
	(74,'Asset',1,0,'2017-09-21 15:55:29','2017-09-21 15:55:29','fb770a4d-3b85-481f-bdf6-b800a5857a6c'),
	(75,'Asset',1,0,'2017-09-21 15:57:23','2017-09-21 15:57:23','31a325c7-568b-4ca4-8cb8-4e99e576e429');

/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_elements_i18n
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements_i18n`;

CREATE TABLE `craft_elements_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elements_i18n_elementId_locale_unq_idx` (`elementId`,`locale`),
  UNIQUE KEY `craft_elements_i18n_uri_locale_unq_idx` (`uri`,`locale`),
  KEY `craft_elements_i18n_slug_locale_idx` (`slug`,`locale`),
  KEY `craft_elements_i18n_enabled_idx` (`enabled`),
  KEY `craft_elements_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_elements_i18n_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_elements_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_elements_i18n` WRITE;
/*!40000 ALTER TABLE `craft_elements_i18n` DISABLE KEYS */;

INSERT INTO `craft_elements_i18n` (`id`, `elementId`, `locale`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_us','',NULL,1,'2017-09-11 21:31:08','2017-10-02 15:17:04','473c2a09-8e38-4579-a9cb-c8f74b6995cf'),
	(2,2,'en_us','homepage','__home__',1,'2017-09-11 21:31:12','2017-09-18 12:40:45','e9f46378-fc31-4115-9cf6-0aad70e457cf'),
	(4,4,'en_us','',NULL,1,'2017-09-12 18:26:20','2017-09-18 13:35:33','d4e74fea-b787-4b03-825d-227aa2352e3b'),
	(5,5,'en_us','60-qatgr',NULL,1,'2017-09-12 20:42:47','2017-09-12 20:42:47','c2dff811-7d60-4681-9de0-23547a1bb04a'),
	(7,7,'en_us','zb-wnxo-r',NULL,1,'2017-09-13 09:35:05','2017-09-13 09:35:05','72a0dda4-a5ea-4f39-9d0c-15f67f42fe10'),
	(8,8,'en_us','the-beginning-of-the-movement','the-beginning-of-the-movement',1,'2017-09-13 17:22:55','2017-09-14 21:16:08','5a9785e3-eb14-42e8-97a2-e62849e9e52f'),
	(9,9,'en_us','',NULL,1,'2017-09-13 17:22:55','2017-09-14 21:16:08','f065eac4-f011-4a11-8cc8-4ca38ff6c7c1'),
	(10,10,'en_us','katie-hetland-175855',NULL,1,'2017-09-13 18:53:54','2017-09-13 18:53:54','b5ef70ad-ee9e-41bd-bbc8-ef89dbbeb707'),
	(11,11,'en_us','2017-01-25-1485324352-6613706-gtywomensmarchwashington4jt170121-12x5-1600',NULL,1,'2017-09-14 00:39:15','2017-09-14 00:39:15','ab4817a9-f07f-4dd9-be9f-1989614781b7'),
	(12,12,'en_us','the-arrests','the-arrests',1,'2017-09-14 00:39:27','2017-09-25 17:32:43','cc39b1b1-703f-49a7-8a05-56a796f3c982'),
	(13,13,'en_us','',NULL,1,'2017-09-14 00:39:27','2017-09-25 17:32:43','31cc96c7-557d-4083-a8df-5a8f704d5e30'),
	(16,16,'en_us','arrests3',NULL,1,'2017-09-14 19:10:01','2017-09-14 19:10:01','f0d53c4e-78d3-4565-a35d-d4b327dc1e56'),
	(17,17,'en_us','',NULL,1,'2017-09-14 19:18:00','2017-09-25 17:32:43','ed824bf5-3786-4137-a433-a6ec28e4ce22'),
	(18,18,'en_us','',NULL,1,'2017-09-14 19:18:00','2017-09-25 17:32:43','ea638098-cbf2-4efa-b352-5895d0feb454'),
	(19,19,'en_us','',NULL,1,'2017-09-14 19:18:00','2017-09-25 17:32:43','95286247-d746-4696-b776-143f1c04e00d'),
	(20,20,'en_us','arrests4',NULL,1,'2017-09-14 19:23:01','2017-09-14 19:23:01','ae615066-b19b-4926-8fdc-a338826f21cc'),
	(21,21,'en_us','arrests5',NULL,1,'2017-09-14 19:23:01','2017-09-14 19:23:01','6c7b1982-2926-494f-821e-c684a41205c8'),
	(22,22,'en_us','arrests4',NULL,1,'2017-09-14 19:29:03','2017-09-14 19:29:03','99ba0434-1ef3-4131-aaa5-31cf2a130cde'),
	(23,23,'en_us','',NULL,1,'2017-09-14 19:31:08','2017-09-25 17:32:43','2ff9facd-3a4d-4281-9e8f-590bb6c928e0'),
	(24,24,'en_us','arrests1',NULL,1,'2017-09-14 19:35:24','2017-09-14 19:35:24','80ab3454-c012-4b09-adb6-0b89745f804d'),
	(25,25,'en_us','amendment1',NULL,1,'2017-09-14 20:29:46','2017-09-14 20:29:46','4bb7eb20-744c-4eaf-8288-71cbd31ec7d0'),
	(26,26,'en_us','amendment2',NULL,1,'2017-09-14 20:29:47','2017-09-14 20:29:47','cff5b093-1b02-4732-966a-34180ddea0de'),
	(27,27,'en_us','amendment3',NULL,1,'2017-09-14 20:29:47','2017-09-14 20:29:47','cfa0a945-85ca-463a-9baf-67524404688f'),
	(28,28,'en_us','amendment4',NULL,1,'2017-09-14 20:29:48','2017-09-14 20:29:48','c51fee81-c882-4b9b-91b8-5686a6e18c38'),
	(29,29,'en_us','amendment5',NULL,1,'2017-09-14 20:29:48','2017-09-14 20:29:48','c84d5823-31bf-4a92-a4f7-26ed941afe55'),
	(30,30,'en_us','amendment6',NULL,1,'2017-09-14 20:29:49','2017-09-14 20:29:49','a4283336-5161-49ed-a310-2c243a03597a'),
	(31,31,'en_us','woodrow-wilson-the-19th-amendment','woodrow-wilson-the-19th-amendment',1,'2017-09-14 20:33:33','2017-09-14 20:42:05','fd695e73-3a94-4ae7-a04e-d87f8c264b46'),
	(32,32,'en_us','',NULL,1,'2017-09-14 20:33:33','2017-09-14 20:42:05','2c16f7ed-24f6-4ce5-b2ae-a09ebe8c5b4f'),
	(33,33,'en_us','',NULL,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','d4876bee-eb0b-461c-8890-eab59c7b2af3'),
	(34,34,'en_us','',NULL,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','1550c597-1ba0-4f76-a3cd-7dd3027e26d1'),
	(35,35,'en_us','',NULL,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','d0607899-cd2c-4545-97f4-93e466e40839'),
	(36,36,'en_us','',NULL,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','01b45a12-4d36-48ff-a51d-371290f6c7fa'),
	(37,37,'en_us','terror1',NULL,1,'2017-09-14 20:48:36','2017-09-14 20:48:36','a9b0a9f2-5bcc-4ab6-bbfa-ffec5e7f22d2'),
	(38,38,'en_us','terror2',NULL,1,'2017-09-14 20:48:36','2017-09-14 20:48:36','13cc53cb-98aa-4aab-a6d6-d72f5f428728'),
	(39,39,'en_us','terror3',NULL,1,'2017-09-14 20:48:37','2017-09-14 20:48:37','656c5986-684a-454c-8985-605184a995ce'),
	(40,40,'en_us','terror4',NULL,1,'2017-09-14 20:48:37','2017-09-14 20:48:37','44045220-487e-405d-bba4-6723a620b0f9'),
	(41,41,'en_us','the-night-of-terror','the-night-of-terror',1,'2017-09-14 20:55:41','2017-09-18 14:02:08','746271fd-1bd7-4c5c-a6d5-1aea4ac38f6a'),
	(42,42,'en_us','',NULL,1,'2017-09-14 20:55:41','2017-09-18 14:02:08','93f82e9d-ddaa-40a6-87cc-af872e75e66d'),
	(43,43,'en_us','',NULL,1,'2017-09-14 20:55:42','2017-09-18 14:02:08','52823479-be64-48b3-969c-d5fa101a0bca'),
	(44,44,'en_us','',NULL,1,'2017-09-14 20:55:42','2017-09-18 14:02:08','6ab55dda-c048-44e4-8303-dcd8e28b9bdc'),
	(45,45,'en_us','',NULL,1,'2017-09-14 20:55:42','2017-09-18 14:02:08','27b8ad1d-1fc8-43fe-a19d-02089afd7123'),
	(46,46,'en_us','movement1',NULL,1,'2017-09-14 21:11:07','2017-09-14 21:11:07','ce3b7961-f3f3-4157-b392-29dd0c6f869a'),
	(47,47,'en_us','movement2',NULL,1,'2017-09-14 21:11:07','2017-09-14 21:11:07','bd5c884e-7995-4f40-9ce4-4da2e6d4f4e6'),
	(48,48,'en_us','movement3',NULL,1,'2017-09-14 21:11:08','2017-09-14 21:11:08','5cb2a416-a659-477b-aa05-ea8ffe31b1ea'),
	(49,49,'en_us','movement4',NULL,1,'2017-09-14 21:11:08','2017-09-14 21:11:08','2660d6a8-1e57-427c-b521-b46981a921f5'),
	(50,50,'en_us','movement5',NULL,1,'2017-09-14 21:11:09','2017-09-14 21:11:09','1dfbc40c-ca4a-44de-b4a8-9812685f4cae'),
	(51,51,'en_us','dude',NULL,1,'2017-09-14 21:13:14','2017-09-14 21:13:14','fd7e7de3-f96a-4333-a9e7-b3fc03674924'),
	(52,52,'en_us','',NULL,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','00bb4b64-339e-4dee-8b23-1123223bafd6'),
	(53,53,'en_us','',NULL,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','c420c06d-418c-4a7c-b9b4-2b6477236763'),
	(54,54,'en_us','',NULL,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','6e556b7a-fc6b-41c2-99c7-0b5640777bb9'),
	(55,55,'en_us','',NULL,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','4bd0c2ea-8977-44cf-ba49-a2f889f5152e'),
	(56,56,'en_us','the-silent-sentinels','bios/the-silent-sentinels',1,'2017-09-15 13:49:44','2017-09-15 13:49:44','340ad113-8a66-4b07-b85b-75eb4f94fb92'),
	(57,57,'en_us','sentinel-bio','sentinel-bio',1,'2017-09-15 13:56:49','2017-09-15 13:56:49','6d712d65-f737-43a3-ba01-03a022be9c26'),
	(58,58,'en_us','home3',NULL,1,'2017-09-15 19:26:59','2017-09-15 19:26:59','bc0c741b-c7d9-4ff6-af42-50c3d7fe9e1a'),
	(59,59,'en_us','logo-twitter',NULL,1,'2017-09-18 12:43:54','2017-09-18 13:33:05','f637c2a0-8ce1-4749-8d61-eb4101d77add'),
	(61,61,'en_us','logo-fb-simple',NULL,1,'2017-09-18 13:32:58','2017-09-18 13:32:58','9697099f-2dd9-491a-ac36-9fdb021f1de7'),
	(62,62,'en_us','logo-instagram',NULL,1,'2017-09-18 13:32:58','2017-09-18 13:32:58','d2ab7942-fda1-4171-928c-61e89c3a565d'),
	(63,63,'en_us','logo-medium',NULL,1,'2017-09-18 13:32:59','2017-09-18 13:32:59','aa79b108-ab01-48e0-ba9f-d85fe5928624'),
	(65,65,'en_us','logo-viget',NULL,1,'2017-09-18 13:32:59','2017-09-18 13:32:59','75e80925-d477-4041-9fbc-b8a1ac7464c8'),
	(66,66,'en_us','logo-alt-fb-simple',NULL,1,'2017-09-18 13:33:55','2017-09-18 13:33:55','d29eabed-f8db-4d2a-926f-2af8c7340829'),
	(67,67,'en_us','logo-alt-instagram',NULL,1,'2017-09-18 13:33:55','2017-09-18 13:33:55','a8da4fe6-d3e1-4bb9-84ef-16049bab2c61'),
	(68,68,'en_us','logo-alt-medium',NULL,1,'2017-09-18 13:33:59','2017-09-18 13:33:59','b288da3c-894a-49c1-beaa-4a4a4072d8ba'),
	(69,69,'en_us','logo-alt-twitter',NULL,1,'2017-09-18 13:34:01','2017-09-18 13:34:01','c6d40994-26b1-494f-a970-7cd12c0d406d'),
	(70,70,'en_us','arrests2',NULL,1,'2017-09-20 13:59:58','2017-09-20 14:05:41','150ab606-666b-4342-b1a9-8590792d03bf'),
	(71,71,'en_us','arrests5',NULL,1,'2017-09-21 13:55:07','2017-09-21 13:55:07','e88c735e-1454-4e88-92ba-a9151f596ea4'),
	(72,72,'en_us','arrests4',NULL,1,'2017-09-21 13:59:30','2017-09-21 13:59:30','8ff28c86-8910-4f68-86b8-61b807c7b153'),
	(73,73,'en_us','arrests3',NULL,1,'2017-09-21 15:55:28','2017-09-21 15:55:28','c3f07727-ae30-46ae-b546-876f4e302173'),
	(74,74,'en_us','arrests6',NULL,1,'2017-09-21 15:55:29','2017-09-21 15:55:29','712758bf-2de5-42ac-b7a1-7a23009565cf'),
	(75,75,'en_us','arrests1',NULL,1,'2017-09-21 15:57:23','2017-09-21 15:57:23','def58114-502a-4a31-b9f2-b1d6d6ba510f');

/*!40000 ALTER TABLE `craft_elements_i18n` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_emailmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_emailmessages`;

CREATE TABLE `craft_emailmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` char(150) COLLATE utf8_unicode_ci NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_emailmessages_key_locale_unq_idx` (`key`,`locale`),
  KEY `craft_emailmessages_locale_fk` (`locale`),
  CONSTRAINT `craft_emailmessages_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entries`;

CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entries_sectionId_idx` (`sectionId`),
  KEY `craft_entries_typeId_idx` (`typeId`),
  KEY `craft_entries_postDate_idx` (`postDate`),
  KEY `craft_entries_expiryDate_idx` (`expiryDate`),
  KEY `craft_entries_authorId_fk` (`authorId`),
  CONSTRAINT `craft_entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;

INSERT INTO `craft_entries` (`id`, `sectionId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,1,NULL,NULL,'2017-09-11 21:31:12',NULL,'2017-09-11 21:31:12','2017-09-18 12:40:45','3eb75f54-43b7-42bb-90f7-9227578a5bed'),
	(8,4,4,1,'2017-09-13 17:22:00',NULL,'2017-09-13 17:22:55','2017-09-14 21:16:08','b3ee28a9-04ca-4d85-b6ed-cb7677665629'),
	(12,4,4,1,'2017-09-14 00:39:00',NULL,'2017-09-14 00:39:27','2017-09-25 17:32:43','9d6b4d84-20da-44b9-82e3-0e4222dc5f73'),
	(31,4,4,1,'2017-09-14 20:30:00',NULL,'2017-09-14 20:33:33','2017-09-14 20:42:06','29e966f7-a984-4eb8-bac5-19c275d7e608'),
	(41,4,4,1,'2017-09-14 20:55:00',NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','54558164-86e9-4435-a9b2-04b5ad49ab05'),
	(56,3,3,1,'2017-09-15 13:49:43',NULL,'2017-09-15 13:49:44','2017-09-15 13:49:44','ad4498f5-d67b-4168-ba41-1b0100fe64b6'),
	(57,5,NULL,NULL,'2017-09-15 13:56:48',NULL,'2017-09-15 13:56:49','2017-09-15 13:56:49','7b2f331e-4aca-4be4-99c4-36836894440f');

/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entrydrafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrydrafts`;

CREATE TABLE `craft_entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafts_entryId_locale_idx` (`entryId`,`locale`),
  KEY `craft_entrydrafts_sectionId_fk` (`sectionId`),
  KEY `craft_entrydrafts_creatorId_fk` (`creatorId`),
  KEY `craft_entrydrafts_locale_fk` (`locale`),
  CONSTRAINT `craft_entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_entrytypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrytypes`;

CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Title',
  `titleFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_entrytypes_name_sectionId_unq_idx` (`name`,`sectionId`),
  UNIQUE KEY `craft_entrytypes_handle_sectionId_unq_idx` (`handle`,`sectionId`),
  KEY `craft_entrytypes_sectionId_fk` (`sectionId`),
  KEY `craft_entrytypes_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;

INSERT INTO `craft_entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,75,'Homepage','homepage',1,'Title',NULL,1,'2017-09-11 21:31:12','2017-09-15 17:31:30','1e1f5059-0e32-4da6-9ccc-7f8dd4d925e0'),
	(2,2,5,'News','news',1,'Title',NULL,1,'2017-09-11 21:31:12','2017-09-11 21:31:12','eafe5b5f-4490-4bcf-8dbb-19f0e3de581b'),
	(3,3,74,'Bios','bios',1,'Title',NULL,1,'2017-09-12 18:15:47','2017-09-15 13:59:51','8f2d19b3-8b37-4781-aa2d-eede48b859d3'),
	(4,4,131,'Timeline','timeline',1,'Title',NULL,1,'2017-09-12 18:23:16','2017-09-25 17:29:58','9bcf4321-1710-43e4-a612-c7d73a92e15e'),
	(5,5,73,'Sentinel Bio','sentinelBio',0,NULL,'{section.name|raw}',1,'2017-09-15 13:56:48','2017-09-15 13:56:48','ca1db9b1-eef8-4f18-8c10-b6cce6640c4c');

/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entryversions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entryversions`;

CREATE TABLE `craft_entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entryversions_entryId_locale_idx` (`entryId`,`locale`),
  KEY `craft_entryversions_sectionId_fk` (`sectionId`),
  KEY `craft_entryversions_creatorId_fk` (`creatorId`),
  KEY `craft_entryversions_locale_fk` (`locale`),
  CONSTRAINT `craft_entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_entryversions` WRITE;
/*!40000 ALTER TABLE `craft_entryversions` DISABLE KEYS */;

INSERT INTO `craft_entryversions` (`id`, `entryId`, `sectionId`, `creatorId`, `locale`, `num`, `notes`, `data`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,2,1,1,'en_us',1,NULL,'{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1505165472,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2017-09-11 21:31:12','2017-09-11 21:31:12','0a1df26d-4823-4e27-b429-637858fc1a92'),
	(2,2,1,1,'en_us',2,NULL,'{\"typeId\":null,\"authorId\":null,\"title\":\"Welcome to Localhost!\",\"slug\":\"homepage\",\"postDate\":1505165472,\"expiryDate\":null,\"enabled\":\"1\",\"parentId\":null,\"fields\":{\"1\":\"<p>It\\u2019s true, this site doesn\\u2019t have a whole lot of content yet, but don\\u2019t worry. Our web developers have just installed the CMS, and they\\u2019re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.<\\/p>\"}}','2017-09-11 21:31:12','2017-09-11 21:31:12','bd956dc5-0efb-4895-b09e-da2aac18985c'),
	(4,2,1,1,'en_us',3,'','{\"typeId\":null,\"authorId\":null,\"title\":\"WHADDUP.\",\"slug\":\"homepage\",\"postDate\":1505165472,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>It\\u2019s true, this site doesn\\u2019t have a whole lot of content yet, but don\\u2019t worry. Our web developers have just installed the CMS, and they\\u2019re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.<\\/p>\"}}','2017-09-12 20:44:43','2017-09-12 20:44:43','cc7b1e08-6f8b-4907-b2d6-610909ff1153'),
	(6,2,1,1,'en_us',4,'','{\"typeId\":null,\"authorId\":null,\"title\":\"WHADDUP.\",\"slug\":\"homepage\",\"postDate\":1505165472,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>It\\u2019s true, this site doesn\\u2019t have a whole lot of content yet, but don\\u2019t worry. Our web developers have just installed the CMS, and they\\u2019re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.<\\/p>\",\"4\":\"#ac7e49\"}}','2017-09-12 21:04:24','2017-09-12 21:04:24','ca3ae1df-154f-49db-a965-7d77274ad553'),
	(7,8,4,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"This is the page title\",\"slug\":\"this-is-the-page-title\",\"postDate\":1505323375,\"expiryDate\":null,\"enabled\":1,\"parentId\":\"\",\"fields\":{\"5\":\"1999-1889\",\"6\":\"Swiggity\",\"8\":{\"new1\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Women; Have they a mission?\",\"quote\":\"We will continue to go to jail.\",\"leadOut\":\"This is the lead out.\",\"attribution\":\"JOHN JAMESON\",\"context\":\"Jan 12, 1995\",\"image\":[\"5\"]}}},\"3\":\"This is the section title\"}}','2017-09-13 17:22:55','2017-09-13 17:22:55','63921443-584c-47cf-b8a6-331aec5e410c'),
	(8,8,4,1,'en_us',2,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Beginning of The Movement\",\"slug\":\"this-is-the-page-title\",\"postDate\":1505323320,\"expiryDate\":null,\"enabled\":1,\"parentId\":\"\",\"fields\":{\"5\":\"1848-1917\",\"6\":\"The Beginning of\",\"8\":{\"9\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Women; Have they a mission?\",\"quote\":\"Yes; It is to rule in the world of love and affection - in the home.\",\"leadOut\":\"It is not to rule in the state. They have a function to perform which precludes the latter sort of rule.\",\"attribution\":\"Rep. Stanley Bowdle (D-Ohio) JAN 12,1915 \",\"context\":\"Jan 12, 1915\",\"image\":[\"10\"]}}},\"3\":\"The Movement\"}}','2017-09-13 19:06:48','2017-09-13 19:06:48','b314de86-28a1-47b2-bd45-9eedf3a5a4fe'),
	(9,12,4,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349567,\"expiryDate\":null,\"enabled\":1,\"parentId\":\"\",\"fields\":{\"5\":\"1917-1919\",\"6\":\"The\",\"8\":{\"new1\":{\"type\":\"factfullbg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"fullBackgroundImage\":[\"11\"]}}},\"3\":\"Arrests\"}}','2017-09-14 00:39:27','2017-09-14 00:39:27','318a409e-d115-4b78-a94d-bfdb95ab455d'),
	(10,8,4,1,'en_us',3,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Beginning of The Movement\",\"slug\":\"this-is-the-page-title\",\"postDate\":1505323320,\"expiryDate\":null,\"enabled\":1,\"parentId\":\"\",\"fields\":{\"5\":\"1848-1917\",\"6\":\"The Beginning of\",\"8\":{\"9\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Women; Have they a mission?\",\"quote\":\"Yes; It is to rule in the world of love and affection - in the home.\",\"leadOut\":\"It is not to rule in the state. They have a function to perform which precludes the latter sort of rule.\",\"attribution\":\"Rep. Stanley Bowdle (D-Ohio) JAN 12,1915 \",\"context\":\"Jan 12, 1915\",\"image\":[\"10\"]}},\"new1\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"An Extreme Idea\",\"image\":[\"11\"],\"statement\":\"\",\"flip\":\"\"}}},\"3\":\"The Movement\"}}','2017-09-14 12:55:37','2017-09-14 12:55:37','b19da22e-197f-4aff-becb-a6f535c3ad09'),
	(11,8,4,1,'en_us',4,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Beginning of The Movement\",\"slug\":\"this-is-the-page-title\",\"postDate\":1505323320,\"expiryDate\":null,\"enabled\":1,\"parentId\":\"\",\"fields\":{\"5\":\"1848-1917\",\"6\":\"The Beginning of\",\"8\":{\"9\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Women; Have they a mission?\",\"quote\":\"Yes; It is to rule in the world of love and affection - in the home.\",\"leadOut\":\"It is not to rule in the state. They have a function to perform which precludes the latter sort of rule.\",\"attribution\":\"Rep. Stanley Bowdle (D-Ohio) JAN 12,1915 \",\"context\":\"Jan 12, 1915\",\"image\":[\"10\"]}},\"14\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"An Extreme Idea\",\"image\":[\"11\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\"}}},\"3\":\"The Movement\"}}','2017-09-14 13:09:08','2017-09-14 13:09:08','036bd372-3452-4f28-8454-be99b8b39be0'),
	(12,8,4,1,'en_us',5,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Beginning of The Movement\",\"slug\":\"the-beginning-of-the-movement\",\"postDate\":1505323320,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1848-1917\",\"6\":\"The Beginning of\",\"8\":{\"9\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Women; Have they a mission?\",\"quote\":\"Yes; It is to rule in the world of love and affection - in the home.\",\"leadOut\":\"It is not to rule in the state. They have a function to perform which precludes the latter sort of rule.\",\"attribution\":\"Rep. Stanley Bowdle (D-Ohio) JAN 12,1915 \",\"context\":\"Jan 12, 1915\",\"image\":[\"10\"]}},\"14\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"An Extreme Idea\",\"image\":[\"11\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\"}}},\"3\":\"The Movement\"}}','2017-09-14 17:36:34','2017-09-14 17:36:34','09359ba7-c894-4e0e-a5ed-e8fd2b4bbab4'),
	(13,12,4,1,'en_us',2,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"15\"]}},\"new1\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":\"\"}},\"new2\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"\",\"flip\":\"\"}},\"new3\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"\",\"context\":\"\",\"image\":\"\"}}},\"3\":\"Arrests\"}}','2017-09-14 19:18:00','2017-09-14 19:18:00','2ea66b5b-3e48-43db-8420-3fe7667664b8'),
	(14,12,4,1,'en_us',3,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"15\"]}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":\"\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"\",\"flip\":\"\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"]}}},\"3\":\"Arrests\"}}','2017-09-14 19:23:57','2017-09-14 19:23:57','cf77d2bb-89d1-4ecf-adb3-884d05b84c62'),
	(15,12,4,1,'en_us',4,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"15\"]}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"]}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\"}},\"new1\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"]}}},\"3\":\"Arrests\"}}','2017-09-14 19:31:08','2017-09-14 19:31:08','0c23d7a1-9196-43dc-b79d-70f937563f4a'),
	(16,12,4,1,'en_us',5,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"15\"]}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"]}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"]}}},\"3\":\"Arrests\"}}','2017-09-14 19:35:28','2017-09-14 19:35:28','ab5ae54b-6a27-4fef-965d-b82cb4b60a06'),
	(17,31,4,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Woodrow Wilson & The 19th Amendment\",\"slug\":\"woodrow-wilson-the-19th-amendment\",\"postDate\":1505421000,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"August 26, 1920\",\"7\":[\"25\"],\"6\":\"Woodrow Wilson &\",\"8\":{\"new1\":{\"type\":\"statementAndImageBlockFull\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"One Step Back\",\"image\":[\"26\"]}}},\"3\":\"The 19th Amendment\"}}','2017-09-14 20:33:33','2017-09-14 20:33:33','def28635-f5de-4e53-8171-36e0af751615'),
	(18,31,4,1,'en_us',2,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"Woodrow Wilson & The 19th Amendment\",\"slug\":\"woodrow-wilson-the-19th-amendment\",\"postDate\":1505421000,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"August 26, 1920\",\"7\":[\"25\"],\"6\":\"Woodrow Wilson &\",\"8\":{\"32\":{\"type\":\"statementAndImageBlockFull\",\"enabled\":\"1\",\"fields\":{\"statement\":\"One Step Back\",\"image\":[\"26\"],\"text\":\"On January 9, 1918, Wilson announced his support of the women\'s suffrage amendment. The next day, the House of Representatives narrowly passed the amendment but the Senate refused to even debate it until October. \\r\\n\\r\\nWhen the Senate voted on the amendment in October, it failed by two votes. And in spite of the ruling by the D.C. Circuit Court of Appeals, arrests of White House protesters resumed on August 6, 1918.\"}},\"new1\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>To keep up the pressure, on December 16, 1918, protesters started burning Wilson\'s words in watch fires in front of the White House.&nbsp;<\\/p>\\r\\n<p>On February 9, 1919, the protesters burned Wilson\'s image in effigy at the White House.<\\/p>\",\"statement\":\"\",\"image\":[\"27\"]}},\"new2\":{\"type\":\"statementAndImageBlockFull\",\"enabled\":\"1\",\"fields\":{\"statement\":\"A Pro-Suffrage Congress\",\"image\":[\"28\"],\"text\":\"On another front, the National Woman\'s Party, led by Paul, urged citizens to vote against anti-suffrage senators up for election in the fall of 1918. After the 1918 election, most members of Congress were pro-suffrage. \\r\\n\\r\\nOn May 21, 1919, the House of Representatives passed the amendment, and two weeks later on June 4, the Senate finally followed. With their work done in Congress, the protesters turned their attention to getting the states to ratify the amendment.  \"}},\"new3\":{\"type\":\"statementAndImageBlockFull\",\"enabled\":\"1\",\"fields\":{\"statement\":\"Narrow Victory\",\"image\":[\"29\"],\"text\":\"It was ratified on August 18, 1920, upon its ratification by Tennessee, the thirty-sixth state to do so by the single vote of a legislator (Harry T. Burn) who had opposed the amendment.\\r\\n\\r\\nHe changed his position after his mother sent him a telegram telling him to support suffrage.\"}},\"new6\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>On AUGUST 26, 1920 Three quarters of the state legislatures ratify the Nineteenth Amendment. &nbsp; \\tAmerican Women win full voting rights.<\\/p>\",\"statement\":\"\",\"image\":[\"30\"]}}},\"3\":\"The 19th Amendment\"}}','2017-09-14 20:42:06','2017-09-14 20:42:06','bc58986c-609a-406e-aed2-4c316225746d'),
	(19,41,4,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"The Night of Terror\",\"slug\":\"the-night-of-terror\",\"postDate\":1505422541,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"Nov. 14, 1917\",\"7\":[\"37\"],\"6\":\"The Night Of\",\"8\":{\"new1\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"In all my years of criminal practice...\",\"quote\":\"I have never seen prisoners so badly treated\",\"leadOut\":\"Either before or after conviction.\",\"attribution\":\"Sen. J. Hamilton Lewis  (D-Illinois)\",\"context\":\"Visiting the Occoquan Workhouse in 1917\",\"image\":[\"38\"]}},\"new3\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"\\\"A Rampage\\\"\",\"image\":[\"39\"],\"statement\":\"Under orders from W. H. Whittaker, superintendent of the Occoquan Workhouse, as many as forty guards with clubs went on a rampage on November 14, 1917, brutalizing thirty-three jailed suffragists. They beat Lucy Burns, chained her hands to the cell bars above her head, and left her there for the night.\",\"flip\":\"\"}},\"new4\":{\"type\":\"quoteStatement\",\"enabled\":\"1\",\"fields\":{\"quote\":\"\\u201cGrabbed Dragged Beaten Choked Slammed Pinched Twisted and Kicked.\\u201d\\r\\n\",\"statementTitle\":\"Terror\",\"statement\":\"They hurled Dora Lewis into a dark cell, smashed her head against an iron bed, and knocked her out cold. \\r\\n\\r\\nHer cellmate Alice Cosu, who believed Mrs. Lewis to be dead, suffered a heart attack. According to affidavits, other women were grabbed, dragged, beaten, choked, slammed, pinched, twisted, and kicked. \"}},\"new5\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Why not let this miserable creature starve. The country would be much better off without her and the balance of her gang of pickets.\",\"quote\":\"They are a rotten lot, and are crazy, and should be locked up for life.\",\"leadOut\":\"\",\"attribution\":\"Letter written to Alice Paul while in prison\",\"context\":\"From an Anti-Suffragist\",\"image\":[\"40\"]}}},\"3\":\"Terror\"}}','2017-09-14 20:55:42','2017-09-14 20:55:42','8bec5ab6-a0df-44a8-9896-6594967f6c21'),
	(20,8,4,1,'en_us',6,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Beginning of The Movement\",\"slug\":\"the-beginning-of-the-movement\",\"postDate\":1505323320,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1848-1917\",\"7\":[\"46\"],\"6\":\"The Beginning of\",\"8\":{\"new1\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"An extreme idea\",\"image\":[\"47\"],\"statement\":\"The demand for women\'s suffrage began to gather strength in the 1840s, emerging from the broader movement for women\'s rights. \\r\\n\\r\\nIn 1848, the Seneca Falls Convention, the first women\'s rights convention, passed a resolution in favor of women\'s suffrage despite opposition from some of its organizers, who believed the idea was too extreme. \\r\\n\\r\\nBy the time of the first National Women\'s Rights Convention in 1850, suffrage was becoming an increasingly important aspect of the movement\'s activities.\",\"flip\":\"\"}},\"new2\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Attempts to Vote\",\"image\":[\"48\"],\"statement\":\"Hoping the U.S. Supreme Court would rule that women had a constitutional right to vote, suffragists made several attempts to vote in the early 1870\\u2019s and then filed lawsuits when they were turned away. \\r\\n\\r\\nSusan B. Anthony succeeded in voting in 1872 but was arrested and found guilty in a widely publicized trial that gave the movement fresh momentum. \",\"flip\":\"1\"}},\"new3\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>After the Supreme Court ruled against the suffragists in 1875, they began the decades-long campaign for an amendment to the U.S. Constitution that would enfranchise women.<\\/p>\",\"statement\":\"\",\"image\":[\"49\"]}},\"9\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Women; Have they a mission?\",\"quote\":\"Yes; It is to rule in the world of love and affection - in the home.\",\"leadOut\":\"It is not to rule in the state. They have a function to perform which precludes the latter sort of rule.\",\"attribution\":\"Rep. Stanley Bowdle (D-Ohio) JAN 12,1915 \",\"context\":\"Jan 12, 1915\",\"image\":[\"51\"]}},\"new4\":{\"type\":\"statementAndImageBlockFull\",\"enabled\":\"1\",\"fields\":{\"statement\":\"The Silent Sentinels\",\"image\":[\"50\"],\"text\":\"Suffragists, known as Silent Sentinels, were the first Americans to picket the White House in U.S. history. They stood for suffrage 6 days a week from January 1917 to June 1919.  Hundreds of women from all over the nation rotated duties. \"}}},\"3\":\"The Movement\"}}','2017-09-14 21:16:08','2017-09-14 21:16:08','1f1113cb-bf87-4c10-96a8-5330a1cf86cb'),
	(21,56,3,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"The Silent Sentinels\",\"slug\":\"the-silent-sentinels\",\"postDate\":1505483383,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2017-09-15 13:49:44','2017-09-15 13:49:44','f7450c27-6a98-4737-8161-d097859287f8'),
	(22,57,5,1,'en_us',1,NULL,'{\"typeId\":\"5\",\"authorId\":null,\"title\":\"Sentinel Bio\",\"slug\":\"sentinel-bio\",\"postDate\":1505483808,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2017-09-15 13:56:49','2017-09-15 13:56:49','7b14ecba-6dbb-4665-8b05-92e202216c0a'),
	(23,2,1,1,'en_us',5,'','{\"typeId\":null,\"authorId\":null,\"title\":\"Test\",\"slug\":\"homepage\",\"postDate\":1505165472,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>It\\u2019s true, this site doesn\\u2019t have a whole lot of content yet, but don\\u2019t worry. Our web developers have just installed the CMS, and they\\u2019re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.<\\/p>\",\"7\":\"\",\"6\":\"\"}}','2017-09-18 12:40:45','2017-09-18 12:40:45','8e039389-4186-455b-84b8-e6fe69da5ab1'),
	(24,41,4,1,'en_us',2,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Night of Terror\",\"slug\":\"the-night-of-terror\",\"postDate\":1505422500,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"Nov. 14, 1917\",\"7\":[\"37\"],\"6\":\"The \",\"8\":{\"42\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"In all my years of criminal practice...\",\"quote\":\"I have never seen prisoners so badly treated\",\"leadOut\":\"Either before or after conviction.\",\"attribution\":\"Sen. J. Hamilton Lewis  (D-Illinois)\",\"context\":\"Visiting the Occoquan Workhouse in 1917\",\"image\":[\"38\"]}},\"43\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"\\\"A Rampage\\\"\",\"image\":[\"39\"],\"statement\":\"Under orders from W. H. Whittaker, superintendent of the Occoquan Workhouse, as many as forty guards with clubs went on a rampage on November 14, 1917, brutalizing thirty-three jailed suffragists. They beat Lucy Burns, chained her hands to the cell bars above her head, and left her there for the night.\",\"flip\":\"\"}},\"44\":{\"type\":\"quoteStatement\",\"enabled\":\"1\",\"fields\":{\"quote\":\"\\u201cGrabbed Dragged Beaten Choked Slammed Pinched Twisted and Kicked.\\u201d\\r\\n\",\"statementTitle\":\"Terror\",\"statement\":\"They hurled Dora Lewis into a dark cell, smashed her head against an iron bed, and knocked her out cold. \\r\\n\\r\\nHer cellmate Alice Cosu, who believed Mrs. Lewis to be dead, suffered a heart attack. According to affidavits, other women were grabbed, dragged, beaten, choked, slammed, pinched, twisted, and kicked. \"}},\"45\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"Why not let this miserable creature starve. The country would be much better off without her and the balance of her gang of pickets.\",\"quote\":\"They are a rotten lot, and are crazy, and should be locked up for life.\",\"leadOut\":\"\",\"attribution\":\"Letter written to Alice Paul while in prison\",\"context\":\"From an Anti-Suffragist\",\"image\":[\"40\"]}}},\"3\":\"Night Of Terror\"}}','2017-09-18 14:02:08','2017-09-18 14:02:08','fa3e943d-6c44-4402-8ad6-d4b671e51bde'),
	(25,12,4,1,'en_us',6,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"]}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"]}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"]}}},\"3\":\"Arrests\"}}','2017-09-20 14:00:43','2017-09-20 14:00:43','4d913193-9689-44d1-85c0-3273fc75a54e'),
	(26,12,4,1,'en_us',7,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"]}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"]}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"]}}},\"3\":\"Arrests\"}}','2017-09-20 14:05:48','2017-09-20 14:05:48','02b31696-61ac-4f1f-b64c-8f88b9dd66b2'),
	(27,12,4,1,'en_us',8,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorswatch\":\"{\\\"label\\\":\\\"red\\\",\\\"color\\\":\\\"#B11C36\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorswatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 18:18:20','2017-09-20 18:18:20','1febe744-a0f0-43fc-9246-76eef0719a8c'),
	(28,12,4,1,'en_us',9,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorswatch\":\"{\\\"label\\\":\\\"red\\\",\\\"color\\\":\\\"#B11C36\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorswatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 18:28:23','2017-09-20 18:28:23','734a702e-391c-4ecb-b7d0-66641af552a0'),
	(29,12,4,1,'en_us',10,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorswatch\":\"{\\\"label\\\":\\\"red\\\",\\\"color\\\":\\\"#B11C36\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorswatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 18:35:46','2017-09-20 18:35:46','0d9a9bbe-24d2-41c6-aec4-360975887142'),
	(30,12,4,1,'en_us',11,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorswatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorswatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 19:52:42','2017-09-20 19:52:42','82adc31e-c032-4182-8ae3-593b4d3c5824'),
	(31,12,4,1,'en_us',12,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 19:53:18','2017-09-20 19:53:18','5b1d5b32-58e1-4d91-a015-8f7b970c949d'),
	(32,12,4,1,'en_us',13,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"As long as women have to go to jail for \\r\\npetty offenses to secure freedom for \\r\\nthe women of America, then \",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"Miss Paul vomits much.  I do, too, except when I\'m not nervous, as I have been every time against my will...  \\r\\n\\r\\nWe think of the coming feeding all day.  It is horrible.  \",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 20:52:57','2017-09-20 20:52:57','5ecdce55-5b1b-4f3a-8839-06bc2e616f02'),
	(33,12,4,1,'en_us',14,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"21\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-20 20:57:12','2017-09-20 20:57:12','fd76ec9e-b041-49ec-bf25-3921ce4425a4'),
	(34,12,4,1,'en_us',15,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D65439\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-21 13:55:25','2017-09-21 13:55:25','f5faebc1-09ff-40c1-9954-08894e1bb73e'),
	(35,12,4,1,'en_us',16,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"22\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D2493B\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D2493B\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-21 13:57:07','2017-09-21 13:57:07','345abea8-a899-4a66-b542-7c1de4158ee9'),
	(36,12,4,1,'en_us',17,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"72\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D2493B\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#D2493B\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-21 13:59:40','2017-09-21 13:59:40','f18eac1a-05c4-4633-b1f3-ed4e480e31f9'),
	(37,12,4,1,'en_us',18,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"72\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-21 14:02:34','2017-09-21 14:02:34','3476f0c9-ded6-4d84-aa59-2dfd7d7f51cd'),
	(38,12,4,1,'en_us',19,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"24\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"72\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"16\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"20\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"1\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-21 14:25:27','2017-09-21 14:25:27','22f703d3-f26d-4096-ace1-2b3cb7447b2e'),
	(39,12,4,1,'en_us',20,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\",\"5\":\"1917-1919\",\"7\":[\"75\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"72\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"74\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"73\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"1\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-21 15:57:36','2017-09-21 15:57:36','8a749f80-feb4-4493-8556-e67e01d8073b'),
	(40,12,4,1,'en_us',21,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"The Arrests\",\"slug\":\"the-arrests\",\"postDate\":1505349540,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"45\":\"{\\\"label\\\":\\\"darkTurqouise\\\",\\\"color\\\":\\\"#024c64\\\"}\",\"5\":\"1917-1919\",\"7\":[\"75\"],\"6\":\"The\",\"8\":{\"13\":{\"type\":\"factFullBg\",\"enabled\":\"1\",\"fields\":{\"fact\":\"<p>Over <strong>500<\\/strong> women were arrested from 1917 to 1919 for picketing the White House in support of women\\u2019s voting rights.&nbsp;<\\/p>\",\"statement\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"image\":[\"70\"],\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"17\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"<p>As long as women have to go to jail for <br>petty offenses to secure freedom for <br>the women of America, then<\\/p>\",\"quote\":\"We will continue to go\\r\\nto jail.\",\"leadOut\":\"\",\"attribution\":\"Anne Henrietta Martin\",\"context\":\"July 18, 1917\",\"image\":[\"72\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}},\"18\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Prisoner Abuse\",\"image\":[\"74\"],\"statement\":\"Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.\",\"flip\":\"\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"23\":{\"type\":\"statementAndImageBlockSplit\",\"enabled\":\"1\",\"fields\":{\"blockTitle\":\"Beaten and Force-Fed\",\"image\":[\"73\"],\"statement\":\"Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.\",\"flip\":\"1\",\"colorSwatch\":\"{\\\"label\\\":\\\"turquoise\\\",\\\"color\\\":\\\"#0B5166\\\"}\"}},\"19\":{\"type\":\"quoteBlock\",\"enabled\":\"1\",\"fields\":{\"leadIn\":\"\",\"quote\":\"Don\'t let them tell you we take this well. \",\"leadOut\":\"<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...<\\/p>\\r\\n<p><br><\\/p>\\r\\n<p>We think of the coming feeding all day. It is horrible.<\\/p>\",\"attribution\":\"Rose Winslow\",\"context\":\"Inside the prison on a smuggled-out note.\",\"image\":[\"71\"],\"colorSwatch\":\"{\\\"label\\\":\\\"orange\\\",\\\"color\\\":\\\"#E35129\\\"}\"}}},\"3\":\"Arrests\"}}','2017-09-25 17:32:43','2017-09-25 17:32:43','905498b4-86f6-4c49-ab7f-9145431c19e2');

/*!40000 ALTER TABLE `craft_entryversions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldgroups`;

CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;

INSERT INTO `craft_fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Default','2017-09-11 21:31:11','2017-09-11 21:31:11','090a0aab-14da-4afd-a055-2090a2a9cc18'),
	(2,'Bios','2017-09-15 13:50:28','2017-09-15 13:50:28','74b38411-9cc4-4013-a4bf-84bef081a388'),
	(3,'Home Page','2017-09-15 17:32:08','2017-09-15 17:32:08','09fe8832-7b02-4539-8459-db7cc6ba8c3e'),
	(4,'social media','2017-09-18 12:44:33','2017-09-18 12:44:33','3d0acf27-f92a-486a-b163-e866a5bb2894'),
	(5,'sentinelBio','2017-09-18 14:11:27','2017-09-18 14:11:27','67d6134f-a26e-4672-9c1b-ac9a4e3c3220');

/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayoutfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;

CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `craft_fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayoutfields_tabId_fk` (`tabId`),
  KEY `craft_fieldlayoutfields_fieldId_fk` (`fieldId`),
  CONSTRAINT `craft_fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayoutfields` DISABLE KEYS */;

INSERT INTO `craft_fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,5,2,1,1,1,'2017-09-11 21:31:12','2017-09-11 21:31:12','11ac5050-d08d-4088-818b-58e7b86ad9fc'),
	(3,5,2,2,0,2,'2017-09-11 21:31:12','2017-09-11 21:31:12','9303bc02-2fa2-4782-b90d-b5c29d5e43a8'),
	(185,74,56,6,0,1,'2017-09-15 13:59:51','2017-09-15 13:59:51','10e11631-acc2-4ff6-b8e1-2b3d79797bdc'),
	(186,74,56,30,0,2,'2017-09-15 13:59:51','2017-09-15 13:59:51','b7193a76-ff48-4603-acd5-9c8c9f5e2b41'),
	(187,74,56,31,0,3,'2017-09-15 13:59:51','2017-09-15 13:59:51','418b959d-1fb1-4009-a3ed-fb97f1f73b96'),
	(188,74,56,7,0,4,'2017-09-15 13:59:51','2017-09-15 13:59:51','f7b3ec6d-8f5d-430b-bb3e-64870683ad3f'),
	(189,75,57,6,0,1,'2017-09-15 17:31:30','2017-09-15 17:31:30','d389a738-968c-4ba6-ad9b-9927d1b17728'),
	(190,75,57,7,0,2,'2017-09-15 17:31:30','2017-09-15 17:31:30','ee679d44-45e8-4a56-9390-d07aa7062b7c'),
	(191,75,57,1,0,3,'2017-09-15 17:31:30','2017-09-15 17:31:30','1ac57d01-d281-4a78-9c79-e99d9fb9ab41'),
	(196,78,60,35,0,1,'2017-09-18 13:21:55','2017-09-18 13:21:55','276007aa-3805-4119-823c-30406daba9e9'),
	(197,78,60,36,0,2,'2017-09-18 13:21:55','2017-09-18 13:21:55','1bb1ca45-7799-49af-89e0-de0756b2729b'),
	(198,78,60,38,0,3,'2017-09-18 13:21:55','2017-09-18 13:21:55','94fa8671-5c45-41c2-b10b-38249e3aa0ef'),
	(199,78,60,37,0,4,'2017-09-18 13:21:55','2017-09-18 13:21:55','6bb9c097-cfa3-4afe-87e6-369f6bf3d6b7'),
	(200,78,60,39,0,5,'2017-09-18 13:21:55','2017-09-18 13:21:55','db711910-19f0-40d6-97cf-6e94c90bba5d'),
	(201,78,60,40,0,6,'2017-09-18 13:21:55','2017-09-18 13:21:55','e975eeea-719f-4d89-969a-903591feda3f'),
	(202,78,60,41,0,7,'2017-09-18 13:21:55','2017-09-18 13:21:55','9c40c2cc-c1b2-427a-aad6-53854742b677'),
	(203,78,60,42,0,8,'2017-09-18 13:21:55','2017-09-18 13:21:55','c047d7c2-3631-4984-9c3b-6593ed121df0'),
	(407,125,107,9,0,1,'2017-09-21 14:01:24','2017-09-21 14:01:24','6a4c78f1-096a-4909-b427-72b40b1a3ecc'),
	(408,125,107,10,0,2,'2017-09-21 14:01:24','2017-09-21 14:01:24','17379d20-4142-444d-8584-2337751c4f54'),
	(409,125,107,11,0,3,'2017-09-21 14:01:24','2017-09-21 14:01:24','3a453720-91e8-41b9-80af-77bac270e675'),
	(410,125,107,12,0,4,'2017-09-21 14:01:24','2017-09-21 14:01:24','216083a6-596d-47aa-9b94-5e4f4d153631'),
	(411,125,107,13,0,5,'2017-09-21 14:01:24','2017-09-21 14:01:24','d5adcd6b-9fdd-442d-a88d-428fab2ac29a'),
	(412,125,107,14,0,6,'2017-09-21 14:01:24','2017-09-21 14:01:24','d71c093b-a211-4c73-bb27-d1c4e99d8b45'),
	(413,125,107,46,0,7,'2017-09-21 14:01:24','2017-09-21 14:01:24','6473cd2e-793f-4406-b31e-a582cf8c775a'),
	(414,126,108,15,1,1,'2017-09-21 14:01:25','2017-09-21 14:01:25','f8d15f72-139e-4bde-aa45-c0a07b1b47a1'),
	(415,126,108,16,0,2,'2017-09-21 14:01:25','2017-09-21 14:01:25','7c1863b2-102d-427d-83ef-4ab1dbf6c4bc'),
	(416,126,108,17,0,3,'2017-09-21 14:01:25','2017-09-21 14:01:25','9d7de45a-0f3e-45ee-8381-2efbeaec61c8'),
	(417,126,108,18,0,4,'2017-09-21 14:01:25','2017-09-21 14:01:25','9458caa5-f9da-42fc-a1db-3c16f826a2d6'),
	(418,126,108,47,0,5,'2017-09-21 14:01:25','2017-09-21 14:01:25','393bb616-3724-4041-97db-48de867792e4'),
	(419,127,109,19,0,1,'2017-09-21 14:01:25','2017-09-21 14:01:25','31308067-71ca-4487-b8b0-1f4d4b2ea625'),
	(420,127,109,20,0,2,'2017-09-21 14:01:25','2017-09-21 14:01:25','7316a406-a78f-4ebb-af10-419401c62d45'),
	(421,127,109,21,0,3,'2017-09-21 14:01:25','2017-09-21 14:01:25','18de94b8-2016-4cfa-b95a-da29a4aa7bc0'),
	(422,127,109,48,0,4,'2017-09-21 14:01:25','2017-09-21 14:01:25','894df21a-c821-4665-99f9-43c353f6bc6f'),
	(423,128,110,22,0,1,'2017-09-21 14:01:25','2017-09-21 14:01:25','b843e78a-f55f-4b33-9c47-4361bba3c337'),
	(424,128,110,23,0,2,'2017-09-21 14:01:25','2017-09-21 14:01:25','d570626a-0edc-4290-9a46-ceb74be4fcbb'),
	(425,128,110,29,0,3,'2017-09-21 14:01:25','2017-09-21 14:01:25','67ad81c1-d012-40c2-a09b-2a718de0c1cc'),
	(426,128,110,49,0,4,'2017-09-21 14:01:25','2017-09-21 14:01:25','ef148c8c-5511-450a-b183-567dbe025e41'),
	(427,129,111,24,0,1,'2017-09-21 14:01:25','2017-09-21 14:01:25','a41a3a8b-cfa3-448a-9b72-3fbeb0583ca1'),
	(428,129,111,25,0,2,'2017-09-21 14:01:25','2017-09-21 14:01:25','c1e6d471-9b63-4141-b9c8-e3cd8b4aa189'),
	(429,129,111,50,0,3,'2017-09-21 14:01:25','2017-09-21 14:01:25','d1791ce9-582d-41a3-aa7f-0fb71cff9109'),
	(430,130,112,26,0,1,'2017-09-21 14:01:25','2017-09-21 14:01:25','32625826-cf10-4f69-9c0e-daba5e566a5a'),
	(431,130,112,27,0,2,'2017-09-21 14:01:25','2017-09-21 14:01:25','9424dd9d-0e7f-4219-bf9f-8f158d671a07'),
	(432,130,112,28,0,3,'2017-09-21 14:01:25','2017-09-21 14:01:25','859fc64b-2ba6-4154-b049-cad16c95c1b3'),
	(433,130,112,51,0,4,'2017-09-21 14:01:25','2017-09-21 14:01:25','c7fc2a03-3efa-4111-b900-18ffe7ee4c17'),
	(434,131,113,6,0,1,'2017-09-25 17:29:58','2017-09-25 17:29:58','5c995cac-d992-4e82-a4a6-88af842f3a11'),
	(435,131,113,3,0,2,'2017-09-25 17:29:58','2017-09-25 17:29:58','5cfdd9f1-271b-48a0-9c1d-2446601c9b1d'),
	(436,131,113,5,0,3,'2017-09-25 17:29:58','2017-09-25 17:29:58','67378384-95c3-4083-9f16-da7252a1bed9'),
	(437,131,113,7,0,4,'2017-09-25 17:29:58','2017-09-25 17:29:58','420385d3-82d5-4c95-af54-973d47aa32b4'),
	(438,131,113,45,0,5,'2017-09-25 17:29:58','2017-09-25 17:29:58','09c95451-4495-4acc-aa52-fc129c3050be'),
	(439,131,113,8,0,6,'2017-09-25 17:29:58','2017-09-25 17:29:58','4c07bffb-6259-407e-bbf1-2557fa2572ac');

/*!40000 ALTER TABLE `craft_fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouts`;

CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouts` DISABLE KEYS */;

INSERT INTO `craft_fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Tag','2017-09-11 21:31:11','2017-09-11 21:31:11','851e7d2d-94c3-4903-8f11-04c178900bd3'),
	(5,'Entry','2017-09-11 21:31:12','2017-09-11 21:31:12','e49a3a1b-b048-426c-8d1e-7125b1221888'),
	(20,'Asset','2017-09-13 09:34:33','2017-09-13 09:34:33','a02d21ee-b75d-4fcd-8884-899dc60db88c'),
	(73,'Entry','2017-09-15 13:56:48','2017-09-15 13:56:48','739c7d63-6633-47e6-af66-d315f5e21f37'),
	(74,'Entry','2017-09-15 13:59:51','2017-09-15 13:59:51','5fbe7878-d8d6-4cb3-b64d-2b89e2d43da2'),
	(75,'Entry','2017-09-15 17:31:30','2017-09-15 17:31:30','12ec3b73-3a1f-400e-8f24-cfd17a8922ca'),
	(78,'GlobalSet','2017-09-18 13:21:54','2017-09-18 13:21:54','0c7f2c4e-f867-4398-b77a-d1da7c97b411'),
	(125,'MatrixBlock','2017-09-21 14:01:24','2017-09-21 14:01:24','27a911ba-1c46-431d-900d-9b9045c72b95'),
	(126,'MatrixBlock','2017-09-21 14:01:25','2017-09-21 14:01:25','769c23f0-49e8-4f0d-b990-957ddd8b0017'),
	(127,'MatrixBlock','2017-09-21 14:01:25','2017-09-21 14:01:25','ccc11904-7b0d-45c0-993a-e586b5755cc1'),
	(128,'MatrixBlock','2017-09-21 14:01:25','2017-09-21 14:01:25','b8b18e82-1c01-4dfe-a78d-86b3e928fdc6'),
	(129,'MatrixBlock','2017-09-21 14:01:25','2017-09-21 14:01:25','60a4d962-fb37-47b9-a0a5-b5d4108d1b73'),
	(130,'MatrixBlock','2017-09-21 14:01:25','2017-09-21 14:01:25','621cef7f-c8ef-4124-bcce-44f9674784ec'),
	(131,'Entry','2017-09-25 17:29:58','2017-09-25 17:29:58','1c06944c-e0fd-4d75-b383-a57d3cdf9db4');

/*!40000 ALTER TABLE `craft_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayouttabs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;

CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayouttabs_layoutId_fk` (`layoutId`),
  CONSTRAINT `craft_fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouttabs` DISABLE KEYS */;

INSERT INTO `craft_fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,5,'Content',1,'2017-09-11 21:31:12','2017-09-11 21:31:12','4b0dfef0-8593-4a7a-a7f1-e2833b166883'),
	(56,74,'Bio Listings',1,'2017-09-15 13:59:51','2017-09-15 13:59:51','a189de07-2cb1-4fe5-b041-08d335fc706f'),
	(57,75,'Content',1,'2017-09-15 17:31:30','2017-09-15 17:31:30','ec669008-1e41-4082-b71f-027da1148d6e'),
	(60,78,'Content',1,'2017-09-18 13:21:54','2017-09-18 13:21:54','4e50e325-b206-45a7-88ca-9985ec717f05'),
	(107,125,'Content',1,'2017-09-21 14:01:24','2017-09-21 14:01:24','4d81e95b-aba2-43cc-b0df-46587148408b'),
	(108,126,'Content',1,'2017-09-21 14:01:25','2017-09-21 14:01:25','a1c57161-c4d0-4252-9ae8-068d0f492f84'),
	(109,127,'Content',1,'2017-09-21 14:01:25','2017-09-21 14:01:25','d7f73712-b23d-4db8-b10b-8246386253d6'),
	(110,128,'Content',1,'2017-09-21 14:01:25','2017-09-21 14:01:25','a83264e6-6122-45f9-9450-eccea4fb337c'),
	(111,129,'Content',1,'2017-09-21 14:01:25','2017-09-21 14:01:25','8e69d873-04a5-4a07-bfe6-f66107bada82'),
	(112,130,'Content',1,'2017-09-21 14:01:25','2017-09-21 14:01:25','5d70dfb9-c58f-443b-9db0-c6d0d526d625'),
	(113,131,'test',1,'2017-09-25 17:29:58','2017-09-25 17:29:58','bae73636-64a9-4512-827f-f5b3b2b89e55');

/*!40000 ALTER TABLE `craft_fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fields`;

CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(58) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `translatable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_fields_context_idx` (`context`),
  KEY `craft_fields_groupId_fk` (`groupId`),
  CONSTRAINT `craft_fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fields` WRITE;
/*!40000 ALTER TABLE `craft_fields` DISABLE KEYS */;

INSERT INTO `craft_fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `translatable`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'Body','body','global',NULL,1,'RichText','{\"configFile\":\"Standard.json\",\"columnType\":\"text\"}','2017-09-11 21:31:11','2017-09-11 21:31:11','7d3198bb-e941-4bf9-87fe-cd552873a6f3'),
	(2,1,'Tags','tags','global',NULL,0,'Tags','{\"source\":\"taggroup:1\"}','2017-09-11 21:31:12','2017-09-11 21:31:12','572ec468-73a9-49db-bb0b-c637fe98a324'),
	(3,1,'Title','titleText','global','Put the title of the section here.',0,'PlainText','{\"placeholder\":\"title pls\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-12 18:34:14','2017-09-12 20:47:54','518c356f-83d8-4caf-b759-982b03ccddb2'),
	(4,1,'color picker','colorPicker','global','pick da color',0,'Color',NULL,'2017-09-12 21:02:59','2017-09-12 21:02:59','32a95527-19f9-4016-b493-0b6285f4b39c'),
	(5,1,'Date','date','global','Enter the date of the event',0,'PlainText','{\"placeholder\":\"????-????\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-13 13:14:17','2017-09-14 20:33:21','13ddd609-335a-4e3a-bdcf-a9c2f318164d'),
	(6,1,'Lead-in','leadIn','global','What\'s the lead into the title?',0,'PlainText','{\"placeholder\":\"The Beginning of \",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-13 13:15:53','2017-09-13 13:15:53','c74490bd-b374-4edd-970c-2f579cc2f57a'),
	(7,1,'image','image','global','Any image in this section? Background or otherwise?',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"limit\":\"1\",\"viewMode\":\"large\",\"selectionLabel\":\"Pick an image\"}','2017-09-13 13:19:29','2017-09-13 13:19:29','8a6843ac-fccb-4137-b8c5-cbdba3a15596'),
	(8,1,'Timeline Content Blocks','timelineMatrix','global','These are the content blocks and related fields for the Timeline set of pages.',0,'Matrix','{\"maxBlocks\":null}','2017-09-13 14:48:13','2017-09-21 14:01:24','1365b4db-32c4-4925-b932-b61ce4afc5e9'),
	(9,NULL,'Lead In','leadIn','matrixBlockType:1','What\'s the lead-in text before the quotation?',0,'RichText','{\"configFile\":\"\",\"availableAssetSources\":\"*\",\"availableTransforms\":\"*\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"purifierConfig\":\"\",\"columnType\":\"text\"}','2017-09-13 14:48:13','2017-09-21 14:01:24','aa5fd8c2-0bd7-4f57-a879-e8dc310a884f'),
	(10,NULL,'Quote','quote','matrixBlockType:1','Place the appropriate quotation here.',0,'PlainText','{\"placeholder\":\"We will continue to go to jail.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 14:48:13','2017-09-21 14:01:24','2b16eaf4-c4b5-490e-84f7-10d7e4079e22'),
	(11,NULL,'Lead Out','leadOut','matrixBlockType:1','The text after a quote and before attribution.',0,'RichText','{\"configFile\":\"\",\"availableAssetSources\":\"*\",\"availableTransforms\":\"*\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"purifierConfig\":\"\",\"columnType\":\"text\"}','2017-09-13 14:48:13','2017-09-21 14:01:24','e9fa97d3-14b7-4124-a1ad-36ca2891260c'),
	(12,NULL,'Attribution','attribution','matrixBlockType:1','Who said the quotation?',0,'PlainText','{\"placeholder\":\"Rep. Stanley Bowdle (D-Ohio)\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 14:48:13','2017-09-21 14:01:24','bd1a6784-e363-4b1d-9a91-91b84c1865a6'),
	(13,NULL,'Context','context','matrixBlockType:1','Perhaps the date or where the speech was made?',0,'PlainText','{\"placeholder\":\"Jan 12, 1915\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 14:48:13','2017-09-21 14:01:24','ad1df41c-65a4-487b-9b33-9ee48d942570'),
	(14,NULL,'Image','image','matrixBlockType:1','What\'s the background image for this block?',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"1\",\"viewMode\":\"large\",\"selectionLabel\":\"Choose your background image.\"}','2017-09-13 14:48:13','2017-09-21 14:01:24','06eae55c-49ae-4430-9c63-50a1a90f5d1d'),
	(15,NULL,'Block Title','blockTitle','matrixBlockType:2','Insert the title for this block.',0,'PlainText','{\"placeholder\":\"AN EXTREME IDEA\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-13 15:17:23','2017-09-21 14:01:25','8dfca65b-b913-47ac-85ad-a23f2d5f70ff'),
	(16,NULL,'Image','image','matrixBlockType:2','Choose the image that will be on the side of the statement and title.',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"1\",\"viewMode\":\"large\",\"selectionLabel\":\"\"}','2017-09-13 15:17:23','2017-09-21 14:01:25','b94f9531-aa4b-4709-9792-575eb8fabb48'),
	(17,NULL,'Statement','statement','matrixBlockType:2','Write the statement for this block\'s field.',0,'PlainText','{\"placeholder\":\"The demand for women\'s suffrage began to gather strength in the 1840s, emerging from the broader movement for women\'s rights.   In 1848, the Seneca Falls Convention, the first women\'s rights convention, passed a resolution in favor of women\'s suffrage despite opposition from some of its organizers, who believed the idea was too extreme.   By the time of the first National Women\'s Rights Convention in 1850, suffrage was becoming an increasingly important aspect of the movement\'s activities.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 15:17:23','2017-09-21 14:01:25','1382b562-3768-4b0a-9488-5c81fa2cf753'),
	(18,NULL,'Flip?','flip','matrixBlockType:2','Want to flip the text from the default left with the image on the default right? CLICK THIS THEN.',0,'Lightswitch','{\"default\":\"\"}','2017-09-13 15:17:23','2017-09-21 14:01:25','c93500ab-c2d5-4e91-ad46-8a5b3ad1c0cd'),
	(19,NULL,'Fact','fact','matrixBlockType:3','Write your initial fact that will lead up into your statement.',0,'RichText','{\"configFile\":\"\",\"availableAssetSources\":\"*\",\"availableTransforms\":\"*\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"purifierConfig\":\"\",\"columnType\":\"text\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','4df3ab06-eee6-4386-b866-d378b205a12e'),
	(20,NULL,'Statement','statement','matrixBlockType:3','Write your statement down here.',0,'PlainText','{\"placeholder\":\"Charges included \\u201cobstruction of traffic\\u201d and \\u201cunlawful assemblage\\u201d.  Women were sentenced  to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','89cbd6ae-1959-44a8-b738-5d600ffb7d47'),
	(21,NULL,'Full Background Image','image','matrixBlockType:3','Pick the full background image you want.',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"1\",\"viewMode\":\"large\",\"selectionLabel\":\"\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','cc2c5d9a-904a-46d4-962b-9824a9d89643'),
	(22,NULL,'Statement','statement','matrixBlockType:4','What\'s the statement of this block?',0,'PlainText','{\"placeholder\":\"The Silent Sentinels\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','fb6e5506-2463-433a-97c4-dfbcc8c15d15'),
	(23,NULL,'Image','image','matrixBlockType:4','Pick your full-width background image.',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"1\",\"viewMode\":\"list\",\"selectionLabel\":\"\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','1a64add3-f7a2-41b1-ab83-a8a6d642e609'),
	(24,NULL,'Fact','fact','matrixBlockType:5','Write your fact for this block.',0,'RichText','{\"configFile\":\"\",\"availableAssetSources\":\"*\",\"availableTransforms\":\"*\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"purifierConfig\":\"\",\"columnType\":\"text\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','c078887e-b013-4239-b314-01495e9121fd'),
	(25,NULL,'Image','image','matrixBlockType:5','Pick the image that will be on the side of the fact.',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"1\",\"viewMode\":\"large\",\"selectionLabel\":\"\"}','2017-09-13 15:17:24','2017-09-21 14:01:25','a9c06592-78f9-4d5a-8006-7552ad796db2'),
	(26,NULL,'Quote','quote','matrixBlockType:6','Write your quotation.',0,'PlainText','{\"placeholder\":\"This is your quotation\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 16:26:18','2017-09-21 14:01:25','3c249c4e-7a99-4b75-997d-8eb138168330'),
	(27,NULL,'Statement Title','statementTitle','matrixBlockType:6','Write the title for your statement here',0,'PlainText','{\"placeholder\":\"This is the title of the statement for this block.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 16:26:18','2017-09-21 14:01:25','4ce15797-bdc7-41d4-8b19-fd2976182da6'),
	(28,NULL,'Statement','statement','matrixBlockType:6','Write your statement here',0,'PlainText','{\"placeholder\":\"After the Supreme Court ruled against the suffragists in 1875, they began the decades-long campaign for an amendment to the U.S. Constitution that would enfranchise women.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-13 16:26:19','2017-09-21 14:01:25','d26f19f2-d46a-4636-b736-9419572b8ed1'),
	(29,NULL,'Text','text','matrixBlockType:4','Place the body text here.',0,'PlainText','{\"placeholder\":\"\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-14 20:32:22','2017-09-21 14:01:25','1f150ab1-7113-4a92-b541-0178dc75df60'),
	(30,2,'Page Title','pageTitle','global','Write the page title here (minus the lead-in).',0,'PlainText','{\"placeholder\":\"Silent Sentinels\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-15 13:52:46','2017-09-15 13:52:46','49916bab-86a1-4ceb-8888-c0086c5a8edc'),
	(31,2,'Description','description','global','Write the page description',0,'PlainText','{\"placeholder\":\"The 72 women who made up the Silent Sentinels picketed, protested, and endured prison to get the right to vote. Each has a story of her own.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-15 13:54:13','2017-09-15 13:54:13','1ff95b4f-37e3-4312-96a8-02d345e12a9c'),
	(32,3,'Description','siteDescription','global','Write the description for the website here.',0,'PlainText','{\"placeholder\":\"It\\u2019s true, this site doesn\\u2019t have a whole lot of content yet, but don\\u2019t worry. Our web developers have just installed the CMS, and they\\u2019re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-15 17:34:14','2017-09-15 17:34:14','33aeca6a-6d7d-4db1-8499-b9a097327633'),
	(33,3,'Description','whoDescription','global','Who were the Silent Sentinels?',0,'RichText','{\"configFile\":\"\",\"availableAssetSources\":\"*\",\"availableTransforms\":\"*\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"purifierConfig\":\"\",\"columnType\":\"text\"}','2017-09-15 17:36:46','2017-09-15 17:36:46','fb2ba4b4-afa2-4b6b-b519-6c3cbece69d8'),
	(34,3,'Description','campaignDescription','global','Write the description for the Campaign and Museum section.',0,'PlainText','{\"placeholder\":\"The Women\\u2019s Suffrage Museum\\u2019s mission is to portray women\\u2019s struggle for equal rights and the opportunity for a vote in our democracy.  The site is considered hallowed ground for the suffragists and for the modern women\\u2019s movement.  It will provide historical context to the movement toward franchise and also provide individual stories of the women who helped bring about the ratification of the 19th Amendment to the U.S. Constitution. \",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-15 17:39:42','2017-09-15 17:39:42','b57e2128-d3b0-4075-9402-7f71c5eb0813'),
	(35,4,'Social #1','social1','global','First Social Media',0,'PlainText','{\"placeholder\":\"Twitter\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-18 12:45:15','2017-09-18 12:45:15','9f84a703-a26c-4632-a4a1-da781e5f2e36'),
	(36,4,'Image #1','image1','global','',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"1\",\"viewMode\":\"list\",\"selectionLabel\":\"\"}','2017-09-18 12:46:05','2017-09-18 12:46:05','385ef128-c933-467a-9ee7-59e5acb5eec6'),
	(37,4,'Image #2','image2','global','',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"\",\"viewMode\":\"list\",\"selectionLabel\":\"\"}','2017-09-18 12:46:34','2017-09-18 12:50:39','ff9738f8-4bbf-4294-9003-d2316f075436'),
	(38,4,'Social #2','social2','global','Second Social Media',0,'PlainText','{\"placeholder\":\"Facebook\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-18 12:46:59','2017-09-18 12:46:59','9260418f-08be-4e0e-88fa-187fb66dc0e6'),
	(39,4,'Social #3','social3','global','Third Social Media',0,'PlainText','{\"placeholder\":\"Medium\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-18 12:47:51','2017-09-18 12:47:51','7e8f4c00-eac4-4fd3-b0c4-05026d97ad7e'),
	(40,4,'Image #3','image3','global','',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"\",\"viewMode\":\"list\",\"selectionLabel\":\"\"}','2017-09-18 12:49:04','2017-09-18 12:49:04','ea96ce58-66b6-409c-9bb6-41e1580af11d'),
	(41,4,'Social #4','social4','global','Fourth Social Media',0,'PlainText','{\"placeholder\":\"Instagram\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-18 12:49:41','2017-09-18 12:49:41','c79fb928-ca46-45f1-a19e-ee2e1fc0d31c'),
	(42,4,'Image #4','image4','global','',0,'Assets','{\"useSingleFolder\":\"\",\"sources\":\"*\",\"defaultUploadLocationSource\":\"1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"limit\":\"\",\"viewMode\":\"list\",\"selectionLabel\":\"\"}','2017-09-18 12:50:12','2017-09-18 12:50:12','4dad4e81-3490-4d22-8249-4d9f64a57750'),
	(43,5,'Name','sentinel','global','Write the name of the Sentinel',0,'PlainText','{\"placeholder\":\"Anne Henrietta Martin\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2017-09-18 14:12:12','2017-09-18 14:12:12','4e582bd7-e909-4c19-8cdb-0c0b95a26a2d'),
	(44,5,'Bio','bio','global','Sentinel Bio',0,'PlainText','{\"placeholder\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse non finibus lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sagittis maximus aliquet. Fusce tristique accumsan lacus at semper. Donec id sapien lectus. Nunc tristique ipsum sed varius dignissim. Vivamus sed sollicitudin eros. Cras aliquet, lectus sed fringilla viverra, quam eros gravida velit, ut aliquam nibh felis sed purus.  Pellentesque eget ante porta, accumsan arcu in, tincidunt nibh. Etiam vel velit lectus. Duis semper condimentum massa. Sed nisl enim, ullamcorper a semper non, lacinia in tellus. Nunc egestas lectus orci, at egestas erat rhoncus ut. Cras ac tempus ante. Vestibulum auctor felis sit amet libero pharetra, non sollicitudin lacus malesuada. Fusce tempor enim at eros luctus finibus.\",\"maxLength\":\"\",\"multiline\":\"1\",\"initialRows\":\"1\"}','2017-09-18 14:13:01','2017-09-18 14:13:01','96edef0f-dc4e-4fe2-8314-bddc732c03a3'),
	(45,1,'Color Swatch','colorSwatch','global','Pick a color.',0,'ColorSwatches','{\"options\":[{\"label\":\"\",\"color\":\"\",\"default\":\"\"},{\"label\":\"teal\",\"color\":\"#16bfc0\",\"default\":\"\"},{\"label\":\"turquoise\",\"color\":\"#008d96\",\"default\":\"\"},{\"label\":\"orange\",\"color\":\"#e65621\",\"default\":\"\"},{\"label\":\"red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"purple\",\"color\":\"#372745\",\"default\":\"\"},{\"label\":\"darkTurqouise\",\"color\":\"#024c64\",\"default\":\"\"},{\"label\":\"yellow\",\"color\":\"#fed95e\",\"default\":\"\"}]}','2017-09-20 17:38:14','2017-09-25 17:32:00','ca0ad8d2-ab45-450b-9386-896ee49be335'),
	(46,NULL,'Color Swatch','colorSwatch','matrixBlockType:1','Pick a background color.',0,'ColorSwatches','{\"options\":[{\"label\":\"teal\",\"color\":\"#0E6C79\",\"default\":\"\"},{\"label\":\"orange\",\"color\":\"#E35129\",\"default\":\"\"},{\"label\":\"red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"turquoise\",\"color\":\"#0B5166\",\"default\":\"\"},{\"label\":\"purple\",\"color\":\"#372E4A\",\"default\":\"\"},{\"label\":\"darkPurple\",\"color\":\"#24223F\",\"default\":\"\"},{\"label\":\"yellow\",\"color\":\"#fed95e\",\"default\":\"\"}]}','2017-09-20 17:47:13','2017-09-21 14:01:24','1127cb68-b147-4a4e-9c3d-365e9bb1c10d'),
	(47,NULL,'Color Swatch','colorSwatch','matrixBlockType:2','',0,'ColorSwatches','{\"options\":[{\"label\":\"teal\",\"color\":\"#0E6C79\",\"default\":\"\"},{\"label\":\"orange\",\"color\":\"#D65439\",\"default\":\"\"},{\"label\":\"red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"turquoise\",\"color\":\"#0B5166\",\"default\":\"\"},{\"label\":\"purple\",\"color\":\"#372E4A\",\"default\":\"\"},{\"label\":\"darkPurple\",\"color\":\"#24223F\",\"default\":\"\"}]}','2017-09-20 17:47:13','2017-09-21 14:01:25','0974207c-30b8-4b27-98d1-319d90dab3e4'),
	(48,NULL,'Color Swatch','colorSwatch','matrixBlockType:3','Pick a background color.',0,'ColorSwatches','{\"options\":[{\"label\":\"teal\",\"color\":\"#0E6C79\",\"default\":\"\"},{\"label\":\"orange\",\"color\":\"#D65439\",\"default\":\"\"},{\"label\":\"red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"turquoise\",\"color\":\"#0B5166\",\"default\":\"\"},{\"label\":\"purple\",\"color\":\"#372E4A\",\"default\":\"\"},{\"label\":\"darkPurple\",\"color\":\"#24223F\",\"default\":\"\"}]}','2017-09-20 17:47:14','2017-09-21 14:01:25','da3b491a-671b-4ef7-afd0-503157b4c296'),
	(49,NULL,'Color Swatch','colorSwatch','matrixBlockType:4','Pick a background color.',0,'ColorSwatches','{\"options\":[{\"label\":\"Teal\",\"color\":\"#0E6C79\",\"default\":\"\"},{\"label\":\"Orange\",\"color\":\"#D65439\",\"default\":\"\"},{\"label\":\"Red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"Turquoise\",\"color\":\"#0B5166\",\"default\":\"\"},{\"label\":\"Purple\",\"color\":\"#372E4A\",\"default\":\"\"},{\"label\":\"Dark Purple\",\"color\":\"#24223F\",\"default\":\"\"}]}','2017-09-20 18:14:14','2017-09-21 14:01:25','c2cdc2f6-9782-49cc-9e37-b5190b7602e4'),
	(50,NULL,'Color Swatch','colorSwatch','matrixBlockType:5','Pick a background color',0,'ColorSwatches','{\"options\":[{\"label\":\"Teal\",\"color\":\"#0E6C79\",\"default\":\"\"},{\"label\":\"Orange\",\"color\":\"#D65439\",\"default\":\"\"},{\"label\":\"Red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"Turquoise\",\"color\":\"#0B5166\",\"default\":\"\"},{\"label\":\"Purple\",\"color\":\"#372E4A\",\"default\":\"\"},{\"label\":\"Dark Purple\",\"color\":\"#24223F\",\"default\":\"\"}]}','2017-09-20 18:14:14','2017-09-21 14:01:25','1c3050e6-8606-43c0-8907-eb9838fcf21b'),
	(51,NULL,'Color Swatch','colorSwatch','matrixBlockType:6','Pick a color background.',0,'ColorSwatches','{\"options\":[{\"label\":\"Teal\",\"color\":\"#0E6C79\",\"default\":\"\"},{\"label\":\"Orange\",\"color\":\"#D65439\",\"default\":\"\"},{\"label\":\"Red\",\"color\":\"#B11C36\",\"default\":\"\"},{\"label\":\"Turquoise\",\"color\":\"#0B5166\",\"default\":\"\"},{\"label\":\"Purple\",\"color\":\"#372E4A\",\"default\":\"\"},{\"label\":\"Dark Purple\",\"color\":\"#24223F\",\"default\":\"\"}]}','2017-09-20 18:14:15','2017-09-21 14:01:25','a9379061-3336-4205-800c-4d0fbcc3866b');

/*!40000 ALTER TABLE `craft_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_globalsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_globalsets`;

CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `craft_globalsets_handle_unq_idx` (`handle`),
  KEY `craft_globalsets_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_globalsets` WRITE;
/*!40000 ALTER TABLE `craft_globalsets` DISABLE KEYS */;

INSERT INTO `craft_globalsets` (`id`, `name`, `handle`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(4,'Social media','socialMedia',78,'2017-09-12 18:26:20','2017-09-18 13:21:55','099ec4c7-e847-490e-9475-df909d18c44c');

/*!40000 ALTER TABLE `craft_globalsets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_info`;

CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `edition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `siteName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `siteUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;

INSERT INTO `craft_info` (`id`, `version`, `schemaVersion`, `edition`, `siteName`, `siteUrl`, `timezone`, `on`, `maintenance`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'2.6.2989','2.6.10',0,'Silent Sentinels - Ben M. Build','http://silentsentinel.dev/','UTC',1,0,'2017-09-11 21:31:05','2017-10-02 14:26:20','fc8e11be-6661-4360-b374-90803e6ed0f2');

/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_locales
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_locales`;

CREATE TABLE `craft_locales` (
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`locale`),
  KEY `craft_locales_sortOrder_idx` (`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_locales` WRITE;
/*!40000 ALTER TABLE `craft_locales` DISABLE KEYS */;

INSERT INTO `craft_locales` (`locale`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	('en_us',1,'2017-09-11 21:31:05','2017-09-11 21:31:05','d6343981-1b12-45bd-9fb9-2366873f89e3');

/*!40000 ALTER TABLE `craft_locales` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocks`;

CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `ownerLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_matrixblocks_ownerId_idx` (`ownerId`),
  KEY `craft_matrixblocks_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocks_typeId_idx` (`typeId`),
  KEY `craft_matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `craft_matrixblocks_ownerLocale_fk` (`ownerLocale`),
  CONSTRAINT `craft_matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerLocale_fk` FOREIGN KEY (`ownerLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks` DISABLE KEYS */;

INSERT INTO `craft_matrixblocks` (`id`, `ownerId`, `fieldId`, `typeId`, `sortOrder`, `ownerLocale`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(9,8,8,1,4,NULL,'2017-09-13 17:22:55','2017-09-14 21:16:08','8b48a327-3ae5-48af-8b67-fd1393ef7abf'),
	(13,12,8,3,1,NULL,'2017-09-14 00:39:27','2017-09-25 17:32:43','becd43f7-6756-4108-b986-e9ab82d982ec'),
	(17,12,8,1,2,NULL,'2017-09-14 19:18:00','2017-09-25 17:32:43','2057ae28-e0f6-4471-ae88-d0b406b05bdf'),
	(18,12,8,2,3,NULL,'2017-09-14 19:18:00','2017-09-25 17:32:43','75567d5a-b2f2-4440-a506-07c1e7e21364'),
	(19,12,8,1,5,NULL,'2017-09-14 19:18:00','2017-09-25 17:32:43','5a659e23-f64f-473e-a3c1-22e147e0ddd0'),
	(23,12,8,2,4,NULL,'2017-09-14 19:31:08','2017-09-25 17:32:43','a7ad8054-08c7-4202-b9c0-3d61c4bb43bb'),
	(32,31,8,4,1,NULL,'2017-09-14 20:33:33','2017-09-14 20:42:05','86797dea-bb18-4015-9652-7a62b9bdadee'),
	(33,31,8,3,2,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','5e93cab0-d3bb-4f2b-8eff-65bf0921690d'),
	(34,31,8,4,3,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','a0a70212-eb1a-4215-8a5e-e29e9a87ae18'),
	(35,31,8,4,4,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','d720a86e-2bd1-4193-a146-23c0fd8ebc5f'),
	(36,31,8,3,5,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','8bff3079-257b-4bde-9285-0dc9b12c0107'),
	(42,41,8,1,1,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','1a8ca4e5-e205-433a-8085-348f5c369e1f'),
	(43,41,8,2,2,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','94a8f899-3340-433c-b39b-ebcb857c2e94'),
	(44,41,8,6,3,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','a67b94c9-ce22-450d-a029-149b5b73ce2d'),
	(45,41,8,1,4,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','4f42eba2-3343-4d1b-829c-6602498f28d4'),
	(52,8,8,2,1,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','f6bd6575-c5c1-4e10-8871-8ac41cd26c06'),
	(53,8,8,2,2,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','adf98979-b203-482d-afdf-60b27fd4e117'),
	(54,8,8,3,3,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','4a7e7b47-d36f-4399-b15d-b03d83a47576'),
	(55,8,8,4,5,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','012a6f66-1341-4789-a52b-1fbe7b2b262e');

/*!40000 ALTER TABLE `craft_matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocktypes`;

CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `craft_matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `craft_matrixblocktypes_fieldId_fk` (`fieldId`),
  KEY `craft_matrixblocktypes_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocktypes` DISABLE KEYS */;

INSERT INTO `craft_matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,8,125,'Quote','quoteBlock',1,'2017-09-13 14:48:13','2017-09-21 14:01:24','ba26a813-cc53-40a0-803a-960decceaba1'),
	(2,8,126,'Statement with a floating image','statementAndImageBlockSplit',2,'2017-09-13 15:17:23','2017-09-21 14:01:25','c0b61561-88a7-4fbe-a9da-712eaa4dcaf3'),
	(3,8,127,'Fact and a Statement with a Background Image','factFullBg',3,'2017-09-13 15:17:24','2017-09-21 14:01:25','093035c6-81ca-4465-9ee1-488f0c703a4c'),
	(4,8,128,'Statement and Image Block FULL','statementAndImageBlockFull',4,'2017-09-13 15:17:24','2017-09-21 14:01:25','fd1f65c8-10a2-47da-8554-1f47d6e3926a'),
	(5,8,129,'Fact and a Statement with a floating Image','factSplitBg',5,'2017-09-13 15:17:24','2017-09-21 14:01:25','292f0fe0-f904-4c02-85e9-41e3bd05d3e1'),
	(6,8,130,'Quote with a Statement','quoteStatement',6,'2017-09-13 16:26:18','2017-09-21 14:01:25','89aec93c-945a-410d-9090-d4a5de4fe09a');

/*!40000 ALTER TABLE `craft_matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixcontent_timelinematrix
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_timelinematrix`;

CREATE TABLE `craft_matrixcontent_timelinematrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `field_quoteBlock_leadIn` text COLLATE utf8_unicode_ci,
  `field_quoteBlock_quote` text COLLATE utf8_unicode_ci,
  `field_quoteBlock_leadOut` text COLLATE utf8_unicode_ci,
  `field_quoteBlock_attribution` text COLLATE utf8_unicode_ci,
  `field_quoteBlock_context` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockSplit_blockTitle` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockSplit_statement` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockSplit_flip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `field_factFullBg_fact` text COLLATE utf8_unicode_ci,
  `field_factFullBg_statement` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockFull_statement` text COLLATE utf8_unicode_ci,
  `field_factSplitBg_fact` text COLLATE utf8_unicode_ci,
  `field_quoteStatement_quote` text COLLATE utf8_unicode_ci,
  `field_quoteStatement_statementTitle` text COLLATE utf8_unicode_ci,
  `field_quoteStatement_statement` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockFull_text` text COLLATE utf8_unicode_ci,
  `field_quoteBlock_colorSwatch` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockSplit_colorSwatch` text COLLATE utf8_unicode_ci,
  `field_factFullBg_colorSwatch` text COLLATE utf8_unicode_ci,
  `field_statementAndImageBlockFull_colorSwatch` text COLLATE utf8_unicode_ci,
  `field_factSplitBg_colorSwatch` text COLLATE utf8_unicode_ci,
  `field_quoteStatement_colorSwatch` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_timelinematrix_elementId_locale_unq_idx` (`elementId`,`locale`),
  KEY `craft_matrixcontent_timelinematrix_locale_idx` (`locale`),
  CONSTRAINT `craft_matrixcontent_timelinematrix_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_timelinematrix_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixcontent_timelinematrix` WRITE;
/*!40000 ALTER TABLE `craft_matrixcontent_timelinematrix` DISABLE KEYS */;

INSERT INTO `craft_matrixcontent_timelinematrix` (`id`, `elementId`, `locale`, `field_quoteBlock_leadIn`, `field_quoteBlock_quote`, `field_quoteBlock_leadOut`, `field_quoteBlock_attribution`, `field_quoteBlock_context`, `field_statementAndImageBlockSplit_blockTitle`, `field_statementAndImageBlockSplit_statement`, `field_statementAndImageBlockSplit_flip`, `field_factFullBg_fact`, `field_factFullBg_statement`, `field_statementAndImageBlockFull_statement`, `field_factSplitBg_fact`, `field_quoteStatement_quote`, `field_quoteStatement_statementTitle`, `field_quoteStatement_statement`, `field_statementAndImageBlockFull_text`, `field_quoteBlock_colorSwatch`, `field_statementAndImageBlockSplit_colorSwatch`, `field_factFullBg_colorSwatch`, `field_statementAndImageBlockFull_colorSwatch`, `field_factSplitBg_colorSwatch`, `field_quoteStatement_colorSwatch`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,9,'en_us','Women; Have they a mission?','Yes; It is to rule in the world of love and affection - in the home.','It is not to rule in the state. They have a function to perform which precludes the latter sort of rule.','Rep. Stanley Bowdle (D-Ohio) JAN 12,1915 ','Jan 12, 1915',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-13 17:22:55','2017-09-14 21:16:08','5720ed8b-a554-4844-9f75-333bd3278e5e'),
	(2,13,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'<p>Over <strong>500</strong> women were arrested from 1917 to 1919 for picketing the White House in support of women’s voting rights. </p>','Charges included “obstruction of traffic” and “unlawful assemblage”.  Women were sentenced to terms in Occoquan Workhouse and District Jail. Of the many women arrested, the youngest was 19 years of age and the oldest at 73 years of age.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label\":\"turquoise\",\"color\":\"#0B5166\",\"__model__\":\"Craft\\\\ColorSwatchesModel\"}',NULL,NULL,NULL,'2017-09-14 00:39:27','2017-09-25 17:32:43','0b9b6675-5179-4b73-ab9a-d3faa4a95ba1'),
	(4,17,'en_us','<p>As long as women have to go to jail for <br />petty offenses to secure freedom for <br />the women of America, then</p>','We will continue to go\r\nto jail.','','Anne Henrietta Martin','July 18, 1917',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label\":\"orange\",\"color\":\"#E35129\",\"__model__\":\"Craft\\\\ColorSwatchesModel\"}',NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:18:00','2017-09-25 17:32:43','dcd89630-c42a-424b-91ee-a6381e8d7486'),
	(5,18,'en_us',NULL,NULL,NULL,NULL,NULL,'Prisoner Abuse','Conditions were deplorable for the women. Food infested with worms,  unhygienic conditions, forced labor, meager and unsanitary food, hunger strikes, forced feedings of strikers, and the contemptuous and sometimes violent treatment the women received from the administrators.',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label\":\"turquoise\",\"color\":\"#0B5166\",\"__model__\":\"Craft\\\\ColorSwatchesModel\"}',NULL,NULL,NULL,NULL,'2017-09-14 19:18:00','2017-09-25 17:32:43','9edf0f38-d2f0-46ae-a795-ab3c20147bb9'),
	(6,19,'en_us','','Don\'t let them tell you we take this well. ','<p>Miss Paul vomits much. I do, too, except when I\'m not nervous, as I have been every time against my will...</p>\n<p><br /></p>\n<p>We think of the coming feeding all day. It is horrible.</p>','Rose Winslow','Inside the prison on a smuggled-out note.',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label\":\"orange\",\"color\":\"#E35129\",\"__model__\":\"Craft\\\\ColorSwatchesModel\"}',NULL,NULL,NULL,NULL,NULL,'2017-09-14 19:18:00','2017-09-25 17:32:43','ec18a5d1-a033-4211-b059-87ce4e42bad1'),
	(7,23,'en_us',NULL,NULL,NULL,NULL,NULL,'Beaten and Force-Fed','Regarding themselves as political prisoners rather than criminals, the silent sentinels refused to eat.  They were threatened, beaten, chained, and force fed by a rubber tube, inserted up the nostril,  through which food was poured into their stomachs.',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label\":\"turquoise\",\"color\":\"#0B5166\",\"__model__\":\"Craft\\\\ColorSwatchesModel\"}',NULL,NULL,NULL,NULL,'2017-09-14 19:31:08','2017-09-25 17:32:43','2a9a9c66-65fb-42d2-958c-99d8c8101de5'),
	(8,32,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'One Step Back',NULL,NULL,NULL,NULL,'On January 9, 1918, Wilson announced his support of the women\'s suffrage amendment. The next day, the House of Representatives narrowly passed the amendment but the Senate refused to even debate it until October. \r\n\r\nWhen the Senate voted on the amendment in October, it failed by two votes. And in spite of the ruling by the D.C. Circuit Court of Appeals, arrests of White House protesters resumed on August 6, 1918.',NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:33:33','2017-09-14 20:42:05','e8dd3f47-44be-46b4-a43d-09ce160f6e54'),
	(9,33,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'<p>To keep up the pressure, on December 16, 1918, protesters started burning Wilson\'s words in watch fires in front of the White House. </p>\n<p>On February 9, 1919, the protesters burned Wilson\'s image in effigy at the White House.</p>','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:42:05','2017-09-14 20:42:05','302c5a1b-37de-49d4-a6a3-b112d6ee72c3'),
	(10,34,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'A Pro-Suffrage Congress',NULL,NULL,NULL,NULL,'On another front, the National Woman\'s Party, led by Paul, urged citizens to vote against anti-suffrage senators up for election in the fall of 1918. After the 1918 election, most members of Congress were pro-suffrage. \r\n\r\nOn May 21, 1919, the House of Representatives passed the amendment, and two weeks later on June 4, the Senate finally followed. With their work done in Congress, the protesters turned their attention to getting the states to ratify the amendment.  ',NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','cf40b050-e590-4289-92df-27620df1eed3'),
	(11,35,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Narrow Victory',NULL,NULL,NULL,NULL,'It was ratified on August 18, 1920, upon its ratification by Tennessee, the thirty-sixth state to do so by the single vote of a legislator (Harry T. Burn) who had opposed the amendment.\r\n\r\nHe changed his position after his mother sent him a telegram telling him to support suffrage.',NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','e8405923-ce19-453e-a678-e8541d62f8db'),
	(12,36,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'<p>On AUGUST 26, 1920 Three quarters of the state legislatures ratify the Nineteenth Amendment.   	American Women win full voting rights.</p>','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:42:06','2017-09-14 20:42:06','297571b3-b5a8-40a2-950a-d3fb08437bbc'),
	(13,42,'en_us','In all my years of criminal practice...','I have never seen prisoners so badly treated','Either before or after conviction.','Sen. J. Hamilton Lewis  (D-Illinois)','Visiting the Occoquan Workhouse in 1917',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:55:41','2017-09-18 14:02:08','db5dce4a-006f-428a-a57d-83f8c63a769e'),
	(14,43,'en_us',NULL,NULL,NULL,NULL,NULL,'\"A Rampage\"','Under orders from W. H. Whittaker, superintendent of the Occoquan Workhouse, as many as forty guards with clubs went on a rampage on November 14, 1917, brutalizing thirty-three jailed suffragists. They beat Lucy Burns, chained her hands to the cell bars above her head, and left her there for the night.',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','cefa9a1f-6c18-48be-8868-ea7a36bf3b80'),
	(15,44,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'“Grabbed Dragged Beaten Choked Slammed Pinched Twisted and Kicked.”\r\n','Terror','They hurled Dora Lewis into a dark cell, smashed her head against an iron bed, and knocked her out cold. \r\n\r\nHer cellmate Alice Cosu, who believed Mrs. Lewis to be dead, suffered a heart attack. According to affidavits, other women were grabbed, dragged, beaten, choked, slammed, pinched, twisted, and kicked. ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','7f7a1fa2-35a4-4770-977a-39c18b851dee'),
	(16,45,'en_us','Why not let this miserable creature starve. The country would be much better off without her and the balance of her gang of pickets.','They are a rotten lot, and are crazy, and should be locked up for life.','','Letter written to Alice Paul while in prison','From an Anti-Suffragist',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 20:55:42','2017-09-18 14:02:08','3ea07bf9-4902-4930-9402-97b66e078c1d'),
	(17,52,'en_us',NULL,NULL,NULL,NULL,NULL,'An extreme idea','The demand for women\'s suffrage began to gather strength in the 1840s, emerging from the broader movement for women\'s rights. \r\n\r\nIn 1848, the Seneca Falls Convention, the first women\'s rights convention, passed a resolution in favor of women\'s suffrage despite opposition from some of its organizers, who believed the idea was too extreme. \r\n\r\nBy the time of the first National Women\'s Rights Convention in 1850, suffrage was becoming an increasingly important aspect of the movement\'s activities.',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','90833be0-ef10-4d8a-a0e9-90bd96e4aba3'),
	(18,53,'en_us',NULL,NULL,NULL,NULL,NULL,'Attempts to Vote','Hoping the U.S. Supreme Court would rule that women had a constitutional right to vote, suffragists made several attempts to vote in the early 1870’s and then filed lawsuits when they were turned away. \r\n\r\nSusan B. Anthony succeeded in voting in 1872 but was arrested and found guilty in a widely publicized trial that gave the movement fresh momentum. ',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','962e993d-0e49-48d0-82ab-169cb7d5be0d'),
	(19,54,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'<p>After the Supreme Court ruled against the suffragists in 1875, they began the decades-long campaign for an amendment to the U.S. Constitution that would enfranchise women.</p>','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','e4bfa89c-4956-44a3-a559-5bfe7f27eae2'),
	(20,55,'en_us',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'The Silent Sentinels',NULL,NULL,NULL,NULL,'Suffragists, known as Silent Sentinels, were the first Americans to picket the White House in U.S. history. They stood for suffrage 6 days a week from January 1917 to June 1919.  Hundreds of women from all over the nation rotated duties. ',NULL,NULL,NULL,NULL,NULL,NULL,'2017-09-14 21:16:08','2017-09-14 21:16:08','8ff5c352-5dbb-431b-a4b1-3413a341c4aa');

/*!40000 ALTER TABLE `craft_matrixcontent_timelinematrix` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_migrations`;

CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_migrations_version_unq_idx` (`version`),
  KEY `craft_migrations_pluginId_fk` (`pluginId`),
  CONSTRAINT `craft_migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;

INSERT INTO `craft_migrations` (`id`, `pluginId`, `version`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'m000000_000000_base','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','0472afc0-3d02-4c4b-a69f-ec7ceddc25e8'),
	(2,NULL,'m140730_000001_add_filename_and_format_to_transformindex','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','8d811035-2772-4cf5-902c-3321a21979fe'),
	(3,NULL,'m140815_000001_add_format_to_transforms','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','9f0005ad-ad40-4eb8-be2f-f76fad9ba6a3'),
	(4,NULL,'m140822_000001_allow_more_than_128_items_per_field','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','60f85139-bbcd-489b-9e6f-59f6d13b3032'),
	(5,NULL,'m140829_000001_single_title_formats','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','587e0543-91d2-4883-a3c5-49541f30651e'),
	(6,NULL,'m140831_000001_extended_cache_keys','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','c5fdf1d6-0019-45c6-aaf8-82f941813b29'),
	(7,NULL,'m140922_000001_delete_orphaned_matrix_blocks','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','d5fccf56-bba3-4a97-b618-37152f4f28d5'),
	(8,NULL,'m141008_000001_elements_index_tune','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','d062f6d9-96fa-423c-9459-752ffde8e56b'),
	(9,NULL,'m141009_000001_assets_source_handle','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','eed31925-7055-41cc-bed5-cbc695c72192'),
	(10,NULL,'m141024_000001_field_layout_tabs','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','56792efc-cfee-4abe-b93e-b0fbbc87976b'),
	(11,NULL,'m141030_000000_plugin_schema_versions','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','b0424ebb-4c7b-48af-843b-3628f4cbc594'),
	(12,NULL,'m141030_000001_drop_structure_move_permission','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','7fcc3b14-cfef-469c-9913-6d8b2de93d3d'),
	(13,NULL,'m141103_000001_tag_titles','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','6b9a6a6c-9602-403a-8e69-d240af0ab5e3'),
	(14,NULL,'m141109_000001_user_status_shuffle','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','f4b63a70-76b8-44a9-8fa9-a3e54485fe1d'),
	(15,NULL,'m141126_000001_user_week_start_day','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','b6e53c56-8017-4293-abdf-9abd21da3c32'),
	(16,NULL,'m150210_000001_adjust_user_photo_size','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','13d61767-6a75-4452-aa08-4e9f2cf03ddc'),
	(17,NULL,'m150724_000001_adjust_quality_settings','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','367ecb2d-0493-4038-a693-f47f79700fea'),
	(18,NULL,'m150827_000000_element_index_settings','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','515a297e-3655-4728-b1b7-3cc4990a04e8'),
	(19,NULL,'m150918_000001_add_colspan_to_widgets','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','ccd50d50-a6b5-431f-ba18-abdecd841cbe'),
	(20,NULL,'m151007_000000_clear_asset_caches','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','d0d8a973-defe-490b-8de6-603d1cca7f0e'),
	(21,NULL,'m151109_000000_text_url_formats','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','20b43c0b-8e07-42ff-b9ec-f186f8afc567'),
	(22,NULL,'m151110_000000_move_logo','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','0ddd64d2-4add-4c85-a5a5-ab241ea24c19'),
	(23,NULL,'m151117_000000_adjust_image_widthheight','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','4f2dfb4b-2a1f-4a59-b6bb-2dbbf175b69b'),
	(24,NULL,'m151127_000000_clear_license_key_status','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','c74986a3-4ef4-4103-8752-7333ce47b287'),
	(25,NULL,'m151127_000000_plugin_license_keys','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','8921bb35-9116-4aca-aee5-9b3d5c0ae6f9'),
	(26,NULL,'m151130_000000_update_pt_widget_feeds','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','f001f596-108c-4e3f-8f2c-ed89466d5abe'),
	(27,NULL,'m160114_000000_asset_sources_public_url_default_true','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','79faa9df-10d3-4112-b92c-6af431d42713'),
	(28,NULL,'m160223_000000_sortorder_to_smallint','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','54fa709b-e2ac-4159-8ff2-850d6708f44f'),
	(29,NULL,'m160229_000000_set_default_entry_statuses','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','f8ac6e0b-c5a3-404e-b873-40c484453d84'),
	(30,NULL,'m160304_000000_client_permissions','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','9e075ac8-abf0-4740-b122-622a9fa16767'),
	(31,NULL,'m160322_000000_asset_filesize','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','6f0243c4-bdeb-4404-854f-52f1a39112e6'),
	(32,NULL,'m160503_000000_orphaned_fieldlayouts','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','13cac22e-a642-4fcc-9325-9f7ead0713cc'),
	(33,NULL,'m160510_000000_tasksettings','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','d97a3359-02e9-4100-b4ca-269724632cff'),
	(34,NULL,'m160829_000000_pending_user_content_cleanup','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','c8ad29cc-86c3-47df-9a35-23fd81de779d'),
	(35,NULL,'m160830_000000_asset_index_uri_increase','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','6f6ccd3e-4138-4fba-b0cb-5e43b404e118'),
	(36,NULL,'m160919_000000_usergroup_handle_title_unique','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','902e16be-f44c-4bb6-b0fd-059cfe35668c'),
	(37,NULL,'m161108_000000_new_version_format','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','5b7e9804-cd98-4f31-8714-0b62fa0eefa0'),
	(38,NULL,'m161109_000000_index_shuffle','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','6cbd5534-a16f-495d-a599-e8c12abd0848'),
	(39,NULL,'m170612_000000_route_index_shuffle','2017-09-11 21:31:05','2017-09-11 21:31:05','2017-09-11 21:31:05','9f26609d-7a43-4b53-b4f1-349e3c149fe0');

/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_plugins`;

CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licenseKey` char(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','unknown') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `settings` text COLLATE utf8_unicode_ci,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;

INSERT INTO `craft_plugins` (`id`, `class`, `version`, `schemaVersion`, `licenseKey`, `licenseKeyStatus`, `enabled`, `settings`, `installDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'GulpRev','2.0',NULL,NULL,'unknown',1,'{\"gulprev_path\":\"\\/assets\"}','2017-09-12 13:47:41','2017-09-12 13:47:41','2017-10-02 15:14:46','cb72ec0c-6c2e-4343-8c5b-96bb7ad87fbd'),
	(2,'cc2kc','1.0',NULL,NULL,'unknown',1,NULL,'2017-09-14 15:34:08','2017-09-14 15:34:08','2017-10-02 15:14:46','dcdb131f-4442-4879-b694-94c9c545d311'),
	(3,'ColorSwatches','1.0.0','1.0.0',NULL,'unknown',1,NULL,'2017-09-20 17:32:38','2017-09-20 17:32:38','2017-10-02 15:14:46','f4ac03f1-6dbe-4430-a848-f67b24eb88a7');

/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_rackspaceaccess
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_rackspaceaccess`;

CREATE TABLE `craft_rackspaceaccess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connectionKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `storageUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cdnUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_rackspaceaccess_connectionKey_unq_idx` (`connectionKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_relations`;

CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_relations_fieldId_sourceId_sourceLocale_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceLocale`,`targetId`),
  KEY `craft_relations_sourceId_fk` (`sourceId`),
  KEY `craft_relations_sourceLocale_fk` (`sourceLocale`),
  KEY `craft_relations_targetId_fk` (`targetId`),
  CONSTRAINT `craft_relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceLocale_fk` FOREIGN KEY (`sourceLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_relations` WRITE;
/*!40000 ALTER TABLE `craft_relations` DISABLE KEYS */;

INSERT INTO `craft_relations` (`id`, `fieldId`, `sourceId`, `sourceLocale`, `targetId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(28,7,31,NULL,25,1,'2017-09-14 20:42:05','2017-09-14 20:42:05','c098505b-ba6a-4871-a739-df3ddb14c8f8'),
	(29,23,32,NULL,26,1,'2017-09-14 20:42:05','2017-09-14 20:42:05','0b92fbbe-32a0-4651-ad1a-e81505432396'),
	(30,21,33,NULL,27,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','42e9845c-d526-4e40-8304-d2cf56befcd7'),
	(31,23,34,NULL,28,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','38362448-399b-4004-8635-e40f37c0da08'),
	(32,23,35,NULL,29,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','204843e6-7c36-423a-94c5-7d63da268c69'),
	(33,21,36,NULL,30,1,'2017-09-14 20:42:06','2017-09-14 20:42:06','bb9f919b-05e1-47fc-b101-3afd1db2437b'),
	(38,7,8,NULL,46,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','884f95c9-5c09-495e-9034-e536aaf9bb0c'),
	(39,16,52,NULL,47,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','c46eb829-5b29-4914-8273-9565cd909ffe'),
	(40,16,53,NULL,48,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','8756f245-b683-4b87-a22d-54d7f23c67a4'),
	(41,21,54,NULL,49,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','c662c8a9-6465-457c-ba7d-54653075d092'),
	(42,14,9,NULL,51,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','8fd9a293-77df-4c99-98ae-372f50be20fe'),
	(43,23,55,NULL,50,1,'2017-09-14 21:16:08','2017-09-14 21:16:08','e8f3053a-d751-4026-ae70-cc5a918c33c5'),
	(44,7,4,NULL,59,1,'2017-09-18 12:44:00','2017-09-18 12:44:00','a9f6343e-86df-4e81-82a5-cfa37452b654'),
	(45,36,4,NULL,68,1,'2017-09-18 13:35:33','2017-09-18 13:35:33','bc1203a4-196d-49fc-9fa3-75e981589123'),
	(46,37,4,NULL,69,1,'2017-09-18 13:35:33','2017-09-18 13:35:33','80e9594a-bf09-498a-8db0-0c2f3997d5ac'),
	(47,40,4,NULL,66,1,'2017-09-18 13:35:33','2017-09-18 13:35:33','a6aec10b-5d20-45ff-9a9f-c296556eb34c'),
	(48,42,4,NULL,67,1,'2017-09-18 13:35:33','2017-09-18 13:35:33','f9b271e9-9f04-488c-afbd-151b0df8978c'),
	(49,7,41,NULL,37,1,'2017-09-18 14:02:08','2017-09-18 14:02:08','96d8f70f-ab1b-4341-a18c-e77a883f151d'),
	(50,14,42,NULL,38,1,'2017-09-18 14:02:08','2017-09-18 14:02:08','f7dc59fd-3c68-4751-b813-e8b0f1082c29'),
	(51,16,43,NULL,39,1,'2017-09-18 14:02:08','2017-09-18 14:02:08','11d7eed3-a2c0-499d-b7f0-0392b4ec9ba6'),
	(52,14,45,NULL,40,1,'2017-09-18 14:02:08','2017-09-18 14:02:08','2e781076-ee12-4169-a233-44113c85752e'),
	(143,7,12,NULL,75,1,'2017-09-25 17:32:43','2017-09-25 17:32:43','19a73088-9e8e-46c3-85c7-2ba3f55019b5'),
	(144,21,13,NULL,70,1,'2017-09-25 17:32:43','2017-09-25 17:32:43','6183b695-5348-467a-9efc-bf2aaafa8004'),
	(145,14,17,NULL,72,1,'2017-09-25 17:32:43','2017-09-25 17:32:43','abed66ac-9d1a-44ba-a740-578d6bf0ab9a'),
	(146,16,18,NULL,74,1,'2017-09-25 17:32:43','2017-09-25 17:32:43','03ac637b-a310-4c8a-800a-a6f65837e241'),
	(147,16,23,NULL,73,1,'2017-09-25 17:32:43','2017-09-25 17:32:43','d49583b1-af30-477d-80e8-d5823ed76c5a'),
	(148,14,19,NULL,71,1,'2017-09-25 17:32:43','2017-09-25 17:32:43','95c23bfa-ce40-4212-984c-7611ade894f7');

/*!40000 ALTER TABLE `craft_relations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_routes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_routes`;

CREATE TABLE `craft_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `urlParts` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `urlPattern` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_routes_locale_idx` (`locale`),
  KEY `craft_routes_urlPattern_idx` (`urlPattern`),
  CONSTRAINT `craft_routes_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_searchindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_searchindex`;

CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`locale`),
  FULLTEXT KEY `craft_searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;

INSERT INTO `craft_searchindex` (`elementId`, `attribute`, `fieldId`, `locale`, `keywords`)
VALUES
	(1,'username',0,'en_us',' benjamin modayil '),
	(1,'firstname',0,'en_us',''),
	(1,'lastname',0,'en_us',''),
	(1,'fullname',0,'en_us',''),
	(1,'email',0,'en_us',' benjamin modayil viget com '),
	(1,'slug',0,'en_us',''),
	(2,'slug',0,'en_us',' homepage '),
	(2,'title',0,'en_us',' test '),
	(2,'field',1,'en_us',' it s true this site doesn t have a whole lot of content yet but don t worry our web developers have just installed the cms and they re setting things up for the content editors this very moment soon localhost will be an oasis of fresh perspectives sharp analyses and astute opinions that will keep you coming back again and again '),
	(71,'extension',0,'en_us',' png '),
	(71,'kind',0,'en_us',' image '),
	(71,'filename',0,'en_us',' arrests5 png '),
	(13,'field',48,'en_us',' turquoise 0b5166 '),
	(17,'field',46,'en_us',' orange e35129 '),
	(18,'field',47,'en_us',' turquoise 0b5166 '),
	(23,'field',47,'en_us',' turquoise 0b5166 '),
	(19,'field',46,'en_us',' orange e35129 '),
	(12,'field',45,'en_us',' darkturqouise 024c64 '),
	(4,'slug',0,'en_us',''),
	(4,'field',3,'en_us',' twitter '),
	(5,'filename',0,'en_us',' 60qatgr jpg '),
	(5,'extension',0,'en_us',' jpg '),
	(5,'kind',0,'en_us',' image '),
	(5,'slug',0,'en_us',' 60 qatgr '),
	(5,'title',0,'en_us',' 60 qatgr '),
	(70,'title',0,'en_us',' arrests2 '),
	(70,'slug',0,'en_us',' arrests2 '),
	(2,'field',4,'en_us',' ac7e49 '),
	(7,'filename',0,'en_us',' zbwnxor mp4 '),
	(7,'extension',0,'en_us',' mp4 '),
	(7,'kind',0,'en_us',' video '),
	(7,'slug',0,'en_us',' zb wnxo r '),
	(7,'title',0,'en_us',' zb wnxo r '),
	(8,'field',6,'en_us',' the beginning of '),
	(8,'field',3,'en_us',' the movement '),
	(8,'field',5,'en_us',' 1848 1917 '),
	(8,'field',8,'en_us',' an extreme idea 0 movement2 the demand for women s suffrage began to gather strength in the 1840s emerging from the broader movement for women s rights in 1848 the seneca falls convention the first women s rights convention passed a resolution in favor of women s suffrage despite opposition from some of its organizers who believed the idea was too extreme by the time of the first national women s rights convention in 1850 suffrage was becoming an increasingly important aspect of the movement s activities attempts to vote 1 movement3 hoping the u s supreme court would rule that women had a constitutional right to vote suffragists made several attempts to vote in the early 1870 s and then filed lawsuits when they were turned away susan b anthony succeeded in voting in 1872 but was arrested and found guilty in a widely publicized trial that gave the movement fresh momentum after the supreme court ruled against the suffragists in 1875 they began the decades long campaign for an amendment to the u s constitution that would enfranchise women movement4 rep stanley bowdle d ohio jan 12 1915 jan 12 1915 dude women have they a mission it is not to rule in the state they have a function to perform which precludes the latter sort of rule yes it is to rule in the world of love and affection in the home movement5 the silent sentinels suffragists known as silent sentinels were the first americans to picket the white house in u s history they stood for suffrage 6 days a week from january 1917 to june 1919 hundreds of women from all over the nation rotated duties '),
	(8,'slug',0,'en_us',' the beginning of the movement '),
	(8,'title',0,'en_us',' the beginning of the movement '),
	(9,'field',9,'en_us',' women have they a mission '),
	(9,'field',10,'en_us',' yes it is to rule in the world of love and affection in the home '),
	(9,'field',11,'en_us',' it is not to rule in the state they have a function to perform which precludes the latter sort of rule '),
	(9,'field',12,'en_us',' rep stanley bowdle d ohio jan 12 1915 '),
	(9,'field',13,'en_us',' jan 12 1915 '),
	(9,'field',14,'en_us',' dude '),
	(9,'slug',0,'en_us',''),
	(10,'filename',0,'en_us',' katie hetland 175855 jpg '),
	(10,'extension',0,'en_us',' jpg '),
	(10,'kind',0,'en_us',' image '),
	(10,'slug',0,'en_us',' katie hetland 175855 '),
	(10,'title',0,'en_us',' katie hetland 175855 '),
	(55,'field',22,'en_us',' the silent sentinels '),
	(11,'filename',0,'en_us',' 2017 01 25 1485324352 6613706 gtywomensmarchwashington4jt170121_12x5_1600 jpg '),
	(11,'extension',0,'en_us',' jpg '),
	(11,'kind',0,'en_us',' image '),
	(11,'slug',0,'en_us',' 2017 01 25 1485324352 6613706 gtywomensmarchwashington4jt170121 12x5 1600 '),
	(11,'title',0,'en_us',' 2017 01 25 1485324352 6613706 gtywomensmarchwashington4jt170121 12x5 1600 '),
	(12,'field',6,'en_us',' the '),
	(12,'field',3,'en_us',' arrests '),
	(12,'field',5,'en_us',' 1917 1919 '),
	(12,'field',8,'en_us',' turquoise 0b5166 over 500 women were arrested from 1917 to 1919 for picketing the white house in support of women s voting rights arrests2 charges included obstruction of traffic and unlawful assemblage women were sentenced to terms in occoquan workhouse and district jail of the many women arrested the youngest was 19 years of age and the oldest at 73 years of age anne henrietta martin orange e35129 july 18 1917 arrests4 as long as women have to go to jail for petty offenses to secure freedom for the women of america then we will continue to go to jail prisoner abuse turquoise 0b5166 0 arrests6 conditions were deplorable for the women food infested with worms unhygienic conditions forced labor meager and unsanitary food hunger strikes forced feedings of strikers and the contemptuous and sometimes violent treatment the women received from the administrators beaten and force fed turquoise 0b5166 1 arrests3 regarding themselves as political prisoners rather than criminals the silent sentinels refused to eat they were threatened beaten chained and force fed by a rubber tube inserted up the nostril through which food was poured into their stomachs rose winslow orange e35129 inside the prison on a smuggled out note arrests5 miss paul vomits much i do too except when i m not nervous as i have been every time against my will we think of the coming feeding all day it is horrible don t let them tell you we take this well '),
	(12,'slug',0,'en_us',' the arrests '),
	(12,'title',0,'en_us',' the arrests '),
	(13,'field',19,'en_us',' over 500 women were arrested from 1917 to 1919 for picketing the white house in support of women s voting rights '),
	(13,'field',20,'en_us',' charges included obstruction of traffic and unlawful assemblage women were sentenced to terms in occoquan workhouse and district jail of the many women arrested the youngest was 19 years of age and the oldest at 73 years of age '),
	(13,'field',21,'en_us',' arrests2 '),
	(17,'field',9,'en_us',' as long as women have to go to jail for petty offenses to secure freedom for the women of america then '),
	(13,'slug',0,'en_us',''),
	(2,'field',6,'en_us',''),
	(58,'slug',0,'en_us',' home3 '),
	(58,'title',0,'en_us',' home3 '),
	(58,'kind',0,'en_us',' image '),
	(56,'slug',0,'en_us',' the silent sentinels '),
	(56,'title',0,'en_us',' the silent sentinels '),
	(57,'slug',0,'en_us',' sentinel bio '),
	(57,'title',0,'en_us',' sentinel bio '),
	(58,'filename',0,'en_us',' home3 png '),
	(58,'extension',0,'en_us',' png '),
	(70,'kind',0,'en_us',' image '),
	(70,'extension',0,'en_us',' png '),
	(70,'filename',0,'en_us',' arrests2 png '),
	(16,'filename',0,'en_us',' arrests3 jpg '),
	(16,'extension',0,'en_us',' jpg '),
	(16,'kind',0,'en_us',' image '),
	(16,'slug',0,'en_us',' arrests3 '),
	(16,'title',0,'en_us',' arrests3 '),
	(17,'field',10,'en_us',' we will continue to go to jail '),
	(17,'field',11,'en_us',''),
	(17,'field',12,'en_us',' anne henrietta martin '),
	(17,'field',13,'en_us',' july 18 1917 '),
	(17,'field',14,'en_us',' arrests4 '),
	(17,'slug',0,'en_us',''),
	(18,'field',15,'en_us',' prisoner abuse '),
	(18,'field',16,'en_us',' arrests6 '),
	(18,'field',17,'en_us',' conditions were deplorable for the women food infested with worms unhygienic conditions forced labor meager and unsanitary food hunger strikes forced feedings of strikers and the contemptuous and sometimes violent treatment the women received from the administrators '),
	(18,'field',18,'en_us',' 0 '),
	(18,'slug',0,'en_us',''),
	(19,'field',9,'en_us',''),
	(19,'field',10,'en_us',' don t let them tell you we take this well '),
	(19,'field',11,'en_us',' miss paul vomits much i do too except when i m not nervous as i have been every time against my will we think of the coming feeding all day it is horrible '),
	(19,'field',12,'en_us',' rose winslow '),
	(19,'field',13,'en_us',' inside the prison on a smuggled out note '),
	(19,'field',14,'en_us',' arrests5 '),
	(19,'slug',0,'en_us',''),
	(20,'filename',0,'en_us',' arrests4 jpg '),
	(20,'extension',0,'en_us',' jpg '),
	(20,'kind',0,'en_us',' image '),
	(20,'slug',0,'en_us',' arrests4 '),
	(20,'title',0,'en_us',' arrests4 '),
	(21,'filename',0,'en_us',' arrests5 jpg '),
	(21,'extension',0,'en_us',' jpg '),
	(21,'kind',0,'en_us',' image '),
	(21,'slug',0,'en_us',' arrests5 '),
	(21,'title',0,'en_us',' arrests5 '),
	(22,'filename',0,'en_us',' arrests4_170914_192902 jpg '),
	(22,'extension',0,'en_us',' jpg '),
	(22,'kind',0,'en_us',' image '),
	(22,'slug',0,'en_us',' arrests4 '),
	(22,'title',0,'en_us',' arrests4 '),
	(23,'field',15,'en_us',' beaten and force fed '),
	(23,'field',16,'en_us',' arrests3 '),
	(23,'field',17,'en_us',' regarding themselves as political prisoners rather than criminals the silent sentinels refused to eat they were threatened beaten chained and force fed by a rubber tube inserted up the nostril through which food was poured into their stomachs '),
	(23,'field',18,'en_us',' 1 '),
	(23,'slug',0,'en_us',''),
	(24,'filename',0,'en_us',' arrests1 jpg '),
	(24,'extension',0,'en_us',' jpg '),
	(24,'kind',0,'en_us',' image '),
	(24,'slug',0,'en_us',' arrests1 '),
	(24,'title',0,'en_us',' arrests1 '),
	(12,'field',7,'en_us',' arrests1 '),
	(25,'filename',0,'en_us',' amendment1 jpg '),
	(25,'extension',0,'en_us',' jpg '),
	(25,'kind',0,'en_us',' image '),
	(25,'slug',0,'en_us',' amendment1 '),
	(25,'title',0,'en_us',' amendment1 '),
	(26,'filename',0,'en_us',' amendment2 jpg '),
	(26,'extension',0,'en_us',' jpg '),
	(26,'kind',0,'en_us',' image '),
	(26,'slug',0,'en_us',' amendment2 '),
	(26,'title',0,'en_us',' amendment2 '),
	(27,'filename',0,'en_us',' amendment3 jpg '),
	(27,'extension',0,'en_us',' jpg '),
	(27,'kind',0,'en_us',' image '),
	(27,'slug',0,'en_us',' amendment3 '),
	(27,'title',0,'en_us',' amendment3 '),
	(28,'filename',0,'en_us',' amendment4 jpg '),
	(28,'extension',0,'en_us',' jpg '),
	(28,'kind',0,'en_us',' image '),
	(28,'slug',0,'en_us',' amendment4 '),
	(28,'title',0,'en_us',' amendment4 '),
	(29,'filename',0,'en_us',' amendment5 jpg '),
	(29,'extension',0,'en_us',' jpg '),
	(29,'kind',0,'en_us',' image '),
	(29,'slug',0,'en_us',' amendment5 '),
	(29,'title',0,'en_us',' amendment5 '),
	(30,'filename',0,'en_us',' amendment6 jpg '),
	(30,'extension',0,'en_us',' jpg '),
	(30,'kind',0,'en_us',' image '),
	(30,'slug',0,'en_us',' amendment6 '),
	(30,'title',0,'en_us',' amendment6 '),
	(31,'field',6,'en_us',' woodrow wilson '),
	(31,'field',3,'en_us',' the 19th amendment '),
	(31,'field',5,'en_us',' august 26 1920 '),
	(31,'field',7,'en_us',' amendment1 '),
	(31,'field',8,'en_us',' amendment2 one step back on january 9 1918 wilson announced his support of the women s suffrage amendment the next day the house of representatives narrowly passed the amendment but the senate refused to even debate it until october when the senate voted on the amendment in october it failed by two votes and in spite of the ruling by the d c circuit court of appeals arrests of white house protesters resumed on august 6 1918 to keep up the pressure on december 16 1918 protesters started burning wilson s words in watch fires in front of the white house on february 9 1919 the protesters burned wilson s image in effigy at the white house amendment3 amendment4 a pro suffrage congress on another front the national woman s party led by paul urged citizens to vote against anti suffrage senators up for election in the fall of 1918 after the 1918 election most members of congress were pro suffrage on may 21 1919 the house of representatives passed the amendment and two weeks later on june 4 the senate finally followed with their work done in congress the protesters turned their attention to getting the states to ratify the amendment amendment5 narrow victory it was ratified on august 18 1920 upon its ratification by tennessee the thirty sixth state to do so by the single vote of a legislator harry t burn who had opposed the amendment he changed his position after his mother sent him a telegram telling him to support suffrage on august 26 1920 three quarters of the state legislatures ratify the nineteenth amendment american women win full voting rights amendment6 '),
	(31,'slug',0,'en_us',' woodrow wilson the 19th amendment '),
	(31,'title',0,'en_us',' woodrow wilson the 19th amendment '),
	(32,'field',22,'en_us',' one step back '),
	(32,'field',23,'en_us',' amendment2 '),
	(32,'field',29,'en_us',' on january 9 1918 wilson announced his support of the women s suffrage amendment the next day the house of representatives narrowly passed the amendment but the senate refused to even debate it until october when the senate voted on the amendment in october it failed by two votes and in spite of the ruling by the d c circuit court of appeals arrests of white house protesters resumed on august 6 1918 '),
	(32,'slug',0,'en_us',''),
	(33,'field',19,'en_us',' to keep up the pressure on december 16 1918 protesters started burning wilson s words in watch fires in front of the white house on february 9 1919 the protesters burned wilson s image in effigy at the white house '),
	(33,'field',20,'en_us',''),
	(33,'field',21,'en_us',' amendment3 '),
	(33,'slug',0,'en_us',''),
	(34,'field',22,'en_us',' a pro suffrage congress '),
	(34,'field',23,'en_us',' amendment4 '),
	(34,'field',29,'en_us',' on another front the national woman s party led by paul urged citizens to vote against anti suffrage senators up for election in the fall of 1918 after the 1918 election most members of congress were pro suffrage on may 21 1919 the house of representatives passed the amendment and two weeks later on june 4 the senate finally followed with their work done in congress the protesters turned their attention to getting the states to ratify the amendment '),
	(34,'slug',0,'en_us',''),
	(35,'field',22,'en_us',' narrow victory '),
	(35,'field',23,'en_us',' amendment5 '),
	(35,'field',29,'en_us',' it was ratified on august 18 1920 upon its ratification by tennessee the thirty sixth state to do so by the single vote of a legislator harry t burn who had opposed the amendment he changed his position after his mother sent him a telegram telling him to support suffrage '),
	(35,'slug',0,'en_us',''),
	(36,'field',19,'en_us',' on august 26 1920 three quarters of the state legislatures ratify the nineteenth amendment american women win full voting rights '),
	(36,'field',20,'en_us',''),
	(36,'field',21,'en_us',' amendment6 '),
	(36,'slug',0,'en_us',''),
	(37,'filename',0,'en_us',' terror1 jpg '),
	(37,'extension',0,'en_us',' jpg '),
	(37,'kind',0,'en_us',' image '),
	(37,'slug',0,'en_us',' terror1 '),
	(37,'title',0,'en_us',' terror1 '),
	(38,'filename',0,'en_us',' terror2 jpg '),
	(38,'extension',0,'en_us',' jpg '),
	(38,'kind',0,'en_us',' image '),
	(38,'slug',0,'en_us',' terror2 '),
	(38,'title',0,'en_us',' terror2 '),
	(39,'filename',0,'en_us',' terror3 jpg '),
	(39,'extension',0,'en_us',' jpg '),
	(39,'kind',0,'en_us',' image '),
	(39,'slug',0,'en_us',' terror3 '),
	(39,'title',0,'en_us',' terror3 '),
	(40,'filename',0,'en_us',' terror4 jpg '),
	(40,'extension',0,'en_us',' jpg '),
	(40,'kind',0,'en_us',' image '),
	(40,'slug',0,'en_us',' terror4 '),
	(40,'title',0,'en_us',' terror4 '),
	(41,'field',6,'en_us',' the '),
	(41,'field',3,'en_us',' night of terror '),
	(41,'field',5,'en_us',' nov 14 1917 '),
	(41,'field',7,'en_us',' terror1 '),
	(41,'field',8,'en_us',' sen j hamilton lewis d illinois visiting the occoquan workhouse in 1917 terror2 in all my years of criminal practice either before or after conviction i have never seen prisoners so badly treated a rampage 0 terror3 under orders from w h whittaker superintendent of the occoquan workhouse as many as forty guards with clubs went on a rampage on november 14 1917 brutalizing thirty three jailed suffragists they beat lucy burns chained her hands to the cell bars above her head and left her there for the night grabbed dragged beaten choked slammed pinched twisted and kicked they hurled dora lewis into a dark cell smashed her head against an iron bed and knocked her out cold her cellmate alice cosu who believed mrs lewis to be dead suffered a heart attack according to affidavits other women were grabbed dragged beaten choked slammed pinched twisted and kicked terror letter written to alice paul while in prison from an anti suffragist terror4 why not let this miserable creature starve the country would be much better off without her and the balance of her gang of pickets they are a rotten lot and are crazy and should be locked up for life '),
	(41,'slug',0,'en_us',' the night of terror '),
	(41,'title',0,'en_us',' the night of terror '),
	(42,'field',9,'en_us',' in all my years of criminal practice '),
	(42,'field',10,'en_us',' i have never seen prisoners so badly treated '),
	(42,'field',11,'en_us',' either before or after conviction '),
	(42,'field',12,'en_us',' sen j hamilton lewis d illinois '),
	(42,'field',13,'en_us',' visiting the occoquan workhouse in 1917 '),
	(42,'field',14,'en_us',' terror2 '),
	(42,'slug',0,'en_us',''),
	(43,'field',15,'en_us',' a rampage '),
	(43,'field',16,'en_us',' terror3 '),
	(43,'field',17,'en_us',' under orders from w h whittaker superintendent of the occoquan workhouse as many as forty guards with clubs went on a rampage on november 14 1917 brutalizing thirty three jailed suffragists they beat lucy burns chained her hands to the cell bars above her head and left her there for the night '),
	(43,'field',18,'en_us',' 0 '),
	(43,'slug',0,'en_us',''),
	(44,'field',26,'en_us',' grabbed dragged beaten choked slammed pinched twisted and kicked '),
	(44,'field',27,'en_us',' terror '),
	(44,'field',28,'en_us',' they hurled dora lewis into a dark cell smashed her head against an iron bed and knocked her out cold her cellmate alice cosu who believed mrs lewis to be dead suffered a heart attack according to affidavits other women were grabbed dragged beaten choked slammed pinched twisted and kicked '),
	(44,'slug',0,'en_us',''),
	(45,'field',9,'en_us',' why not let this miserable creature starve the country would be much better off without her and the balance of her gang of pickets '),
	(45,'field',10,'en_us',' they are a rotten lot and are crazy and should be locked up for life '),
	(45,'field',11,'en_us',''),
	(45,'field',12,'en_us',' letter written to alice paul while in prison '),
	(45,'field',13,'en_us',' from an anti suffragist '),
	(45,'field',14,'en_us',' terror4 '),
	(45,'slug',0,'en_us',''),
	(46,'filename',0,'en_us',' movement1 jpg '),
	(46,'extension',0,'en_us',' jpg '),
	(46,'kind',0,'en_us',' image '),
	(46,'slug',0,'en_us',' movement1 '),
	(46,'title',0,'en_us',' movement1 '),
	(47,'filename',0,'en_us',' movement2 jpg '),
	(47,'extension',0,'en_us',' jpg '),
	(47,'kind',0,'en_us',' image '),
	(47,'slug',0,'en_us',' movement2 '),
	(47,'title',0,'en_us',' movement2 '),
	(48,'filename',0,'en_us',' movement3 jpg '),
	(48,'extension',0,'en_us',' jpg '),
	(48,'kind',0,'en_us',' image '),
	(48,'slug',0,'en_us',' movement3 '),
	(48,'title',0,'en_us',' movement3 '),
	(49,'filename',0,'en_us',' movement4 jpg '),
	(49,'extension',0,'en_us',' jpg '),
	(49,'kind',0,'en_us',' image '),
	(49,'slug',0,'en_us',' movement4 '),
	(49,'title',0,'en_us',' movement4 '),
	(50,'filename',0,'en_us',' movement5 jpg '),
	(50,'extension',0,'en_us',' jpg '),
	(50,'kind',0,'en_us',' image '),
	(50,'slug',0,'en_us',' movement5 '),
	(50,'title',0,'en_us',' movement5 '),
	(51,'filename',0,'en_us',' dude jpg '),
	(51,'extension',0,'en_us',' jpg '),
	(51,'kind',0,'en_us',' image '),
	(51,'slug',0,'en_us',' dude '),
	(51,'title',0,'en_us',' dude '),
	(8,'field',7,'en_us',' movement1 '),
	(52,'field',15,'en_us',' an extreme idea '),
	(52,'field',16,'en_us',' movement2 '),
	(52,'field',17,'en_us',' the demand for women s suffrage began to gather strength in the 1840s emerging from the broader movement for women s rights in 1848 the seneca falls convention the first women s rights convention passed a resolution in favor of women s suffrage despite opposition from some of its organizers who believed the idea was too extreme by the time of the first national women s rights convention in 1850 suffrage was becoming an increasingly important aspect of the movement s activities '),
	(52,'field',18,'en_us',' 0 '),
	(52,'slug',0,'en_us',''),
	(53,'field',15,'en_us',' attempts to vote '),
	(53,'field',16,'en_us',' movement3 '),
	(53,'field',17,'en_us',' hoping the u s supreme court would rule that women had a constitutional right to vote suffragists made several attempts to vote in the early 1870 s and then filed lawsuits when they were turned away susan b anthony succeeded in voting in 1872 but was arrested and found guilty in a widely publicized trial that gave the movement fresh momentum '),
	(53,'field',18,'en_us',' 1 '),
	(53,'slug',0,'en_us',''),
	(54,'field',19,'en_us',' after the supreme court ruled against the suffragists in 1875 they began the decades long campaign for an amendment to the u s constitution that would enfranchise women '),
	(54,'field',20,'en_us',''),
	(54,'field',21,'en_us',' movement4 '),
	(54,'slug',0,'en_us',''),
	(55,'field',23,'en_us',' movement5 '),
	(55,'field',29,'en_us',' suffragists known as silent sentinels were the first americans to picket the white house in u s history they stood for suffrage 6 days a week from january 1917 to june 1919 hundreds of women from all over the nation rotated duties '),
	(55,'slug',0,'en_us',''),
	(2,'field',7,'en_us',''),
	(4,'field',7,'en_us',' logo twitter '),
	(59,'filename',0,'en_us',' logo twitter png '),
	(59,'extension',0,'en_us',' png '),
	(59,'kind',0,'en_us',' image '),
	(59,'slug',0,'en_us',' logo twitter '),
	(59,'title',0,'en_us',' logo twitter '),
	(4,'field',35,'en_us',' medium '),
	(4,'field',36,'en_us',' logo alt medium '),
	(4,'field',38,'en_us',' twitter '),
	(4,'field',37,'en_us',' logo alt twitter '),
	(4,'field',39,'en_us',' facebook '),
	(4,'field',40,'en_us',' logo alt fb simple '),
	(4,'field',41,'en_us',' instagram '),
	(4,'field',42,'en_us',' logo alt instagram '),
	(61,'kind',0,'en_us',' image '),
	(61,'slug',0,'en_us',' logo fb simple '),
	(61,'extension',0,'en_us',' png '),
	(61,'filename',0,'en_us',' logo fb simple png '),
	(61,'title',0,'en_us',' logo fb simple '),
	(62,'filename',0,'en_us',' logo instagram png '),
	(62,'extension',0,'en_us',' png '),
	(62,'kind',0,'en_us',' image '),
	(62,'slug',0,'en_us',' logo instagram '),
	(62,'title',0,'en_us',' logo instagram '),
	(63,'filename',0,'en_us',' logo medium png '),
	(63,'extension',0,'en_us',' png '),
	(63,'kind',0,'en_us',' image '),
	(63,'slug',0,'en_us',' logo medium '),
	(63,'title',0,'en_us',' logo medium '),
	(66,'kind',0,'en_us',' image '),
	(66,'slug',0,'en_us',' logo alt fb simple '),
	(66,'extension',0,'en_us',' png '),
	(66,'filename',0,'en_us',' logo alt fb simple png '),
	(65,'filename',0,'en_us',' logo viget png '),
	(65,'extension',0,'en_us',' png '),
	(65,'kind',0,'en_us',' image '),
	(65,'slug',0,'en_us',' logo viget '),
	(65,'title',0,'en_us',' logo viget '),
	(66,'title',0,'en_us',' logo alt fb simple '),
	(67,'filename',0,'en_us',' logo alt instagram png '),
	(67,'extension',0,'en_us',' png '),
	(67,'kind',0,'en_us',' image '),
	(67,'slug',0,'en_us',' logo alt instagram '),
	(67,'title',0,'en_us',' logo alt instagram '),
	(68,'filename',0,'en_us',' logo alt medium png '),
	(68,'extension',0,'en_us',' png '),
	(68,'kind',0,'en_us',' image '),
	(68,'slug',0,'en_us',' logo alt medium '),
	(68,'title',0,'en_us',' logo alt medium '),
	(69,'filename',0,'en_us',' logo alt twitter png '),
	(69,'extension',0,'en_us',' png '),
	(69,'kind',0,'en_us',' image '),
	(69,'slug',0,'en_us',' logo alt twitter '),
	(69,'title',0,'en_us',' logo alt twitter '),
	(71,'slug',0,'en_us',' arrests5 '),
	(71,'title',0,'en_us',' arrests5 '),
	(72,'filename',0,'en_us',' arrests4 png '),
	(72,'extension',0,'en_us',' png '),
	(72,'kind',0,'en_us',' image '),
	(72,'slug',0,'en_us',' arrests4 '),
	(72,'title',0,'en_us',' arrests4 '),
	(73,'filename',0,'en_us',' arrests3 png '),
	(73,'extension',0,'en_us',' png '),
	(73,'kind',0,'en_us',' image '),
	(73,'slug',0,'en_us',' arrests3 '),
	(73,'title',0,'en_us',' arrests3 '),
	(74,'filename',0,'en_us',' arrests6 png '),
	(74,'extension',0,'en_us',' png '),
	(74,'kind',0,'en_us',' image '),
	(74,'slug',0,'en_us',' arrests6 '),
	(74,'title',0,'en_us',' arrests6 '),
	(75,'filename',0,'en_us',' arrests1 png '),
	(75,'extension',0,'en_us',' png '),
	(75,'kind',0,'en_us',' image '),
	(75,'slug',0,'en_us',' arrests1 '),
	(75,'title',0,'en_us',' arrests1 ');

/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections`;

CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `hasUrls` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enableVersioning` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_name_unq_idx` (`name`),
  UNIQUE KEY `craft_sections_handle_unq_idx` (`handle`),
  KEY `craft_sections_structureId_fk` (`structureId`),
  CONSTRAINT `craft_sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;

INSERT INTO `craft_sections` (`id`, `structureId`, `name`, `handle`, `type`, `hasUrls`, `template`, `enableVersioning`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'Homepage','homepage','single',1,'index',1,'2017-09-11 21:31:12','2017-09-11 21:31:12','78fcfb78-fc70-45c7-a20b-b3639ed1ed90'),
	(2,NULL,'News','news','channel',1,'news/_entry',1,'2017-09-11 21:31:12','2017-09-11 21:31:12','fe489603-48cd-4798-bebb-688816b44723'),
	(3,NULL,'Bios','bios','channel',1,'bios/_entry',1,'2017-09-12 18:15:47','2017-09-15 13:47:05','e5571e0e-f6c1-4ded-8cf1-05a35ec38778'),
	(4,1,'Timeline','timeline','structure',1,'timeline/_entry',1,'2017-09-12 18:23:16','2017-09-14 14:13:04','a8153687-5f0f-479f-9052-b94c1a319b51'),
	(5,NULL,'Sentinel Bio','sentinelBio','single',1,'sentinel-bio',1,'2017-09-15 13:56:48','2017-09-15 13:56:48','e9a49bca-651f-4cb0-bf43-92fbfa43e51b');

/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections_i18n
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections_i18n`;

CREATE TABLE `craft_sections_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `enabledByDefault` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `urlFormat` text COLLATE utf8_unicode_ci,
  `nestedUrlFormat` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_i18n_sectionId_locale_unq_idx` (`sectionId`,`locale`),
  KEY `craft_sections_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_sections_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_sections_i18n_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_sections_i18n` WRITE;
/*!40000 ALTER TABLE `craft_sections_i18n` DISABLE KEYS */;

INSERT INTO `craft_sections_i18n` (`id`, `sectionId`, `locale`, `enabledByDefault`, `urlFormat`, `nestedUrlFormat`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_us',1,'__home__',NULL,'2017-09-11 21:31:12','2017-09-11 21:31:12','a956367d-be10-49c6-b3f2-54aab09092db'),
	(2,2,'en_us',1,'news/{postDate.year}/{slug}',NULL,'2017-09-11 21:31:12','2017-09-11 21:31:12','a2a3017a-561f-4414-b572-6c537521d539'),
	(3,3,'en_us',1,'bios/{slug}',NULL,'2017-09-12 18:15:47','2017-09-12 18:15:47','0c21303b-a8fa-4c34-9736-f0fad6024b90'),
	(4,4,'en_us',1,'{slug}',NULL,'2017-09-12 18:23:16','2017-09-14 14:13:04','c432bda6-d708-4bb0-bb80-ac8006fcb5b4'),
	(5,5,'en_us',1,'sentinel-bio',NULL,'2017-09-15 13:56:48','2017-09-15 13:56:48','8106752c-8245-4e5e-b49c-8323d2304160');

/*!40000 ALTER TABLE `craft_sections_i18n` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sessions`;

CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sessions_uid_idx` (`uid`),
  KEY `craft_sessions_token_idx` (`token`),
  KEY `craft_sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `craft_sessions_userId_fk` (`userId`),
  CONSTRAINT `craft_sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_sessions` WRITE;
/*!40000 ALTER TABLE `craft_sessions` DISABLE KEYS */;

INSERT INTO `craft_sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'c82daf4e0ff9afc31957a2468d372836fa2e559eczozMjoiZm1KQlFKSmNMSEpwNUt+OUFGd3F5WmhxX29EUmxpb0MiOw==','2017-09-11 21:31:11','2017-09-11 21:31:11','ab7551f5-e51d-464f-a3c8-e8982d4347ea'),
	(2,1,'af231c8aedbd2365e94e660cf00297950b38bb37czozMjoiTjFMWWRZfkVtOGlzb1E4fldPZTdSanEyOVpQOG42fnEiOw==','2017-09-12 13:21:38','2017-09-12 13:21:38','bbdb1410-5913-43ec-854b-b2d17ec0aabf'),
	(4,1,'3a63e4d854eea3a32b890963e09f74cd563b1e10czozMjoiWjd5RnJHeXZvUGQyU3FoSkJBRU5JejFCa0pYcE43V2IiOw==','2017-09-12 18:08:52','2017-09-12 18:08:52','8921a4d8-fefb-4321-8319-50682c4353ec'),
	(5,1,'190752ff13d8173577157c587ef73002d810e3edczozMjoiNjJiZ0xnS2VTald3QXRuZGNDek1VNTBSd0s4SENOVE0iOw==','2017-09-12 20:17:08','2017-09-12 20:17:08','01292bbc-799c-487f-afbc-bfea29dabbd4'),
	(6,1,'69fec1f7619f37a3371dc2789892f24cabd53e17czozMjoic2xMQVBUbHFWeGZPSGNwQ09SeXBXNHlocGdoZmozcVQiOw==','2017-09-13 09:33:29','2017-09-13 09:33:29','50cfd126-0b4f-4be4-80e5-b9046f5c1f60'),
	(7,1,'167cb966b177a9c47aac84a59aab39cda1a0f46dczozMjoicXlaZmJKcGtHUkhPakRhYjJWZEZYYmZ5amVTVkU2X3AiOw==','2017-09-15 13:43:33','2017-09-15 13:43:33','42753541-f774-4daa-accd-119763cbf920'),
	(8,1,'1821c004fcc4a0bc857d2fc1f5e3afb05db174edczozMjoiZzBGaTdTUGcwaENWdkdRR2hYZFU1YW9Tc2pMVE9EZ3UiOw==','2017-09-15 17:22:00','2017-09-15 17:22:00','7fa3d934-fbf7-4c9e-80d8-b640f878e332'),
	(9,1,'1339e23a75ba9bd848aa599bfc4106ab382d46c6czozMjoiSFZIUXZTSlBSaDRHVzdKWFZOZ19GZFd4c0FiVEh+a0YiOw==','2017-09-15 19:24:56','2017-09-15 19:24:56','b2bb1b65-0945-4283-8e8a-746c30306565'),
	(10,1,'8fea8c11b7f609b16018be6a0224120797a021b4czozMjoicXB0Q0tyNmhDaEdIc1k3SWFDWX5ZX0R1MFN+TzloZVUiOw==','2017-09-20 13:59:02','2017-09-20 13:59:02','3549b686-2702-43ab-8bf8-a8a38a7b5348'),
	(11,1,'fb07e1155419a874dbfde2fc6ea9770392dd1784czozMjoiV1cwTjVpb0dURE9kSVhYUTFIbURhNjRhUVFvSXdFTnciOw==','2017-09-21 13:52:29','2017-09-21 13:52:29','a6ac42fe-a09c-4b9b-b572-217749b3aed6'),
	(12,1,'796580c3569a5b4a05515c278e99c218c03e0bb0czozMjoiUkh2RW9LUWlLallCRVN6eGpObTAzRXQ4ZHdmNENsMlciOw==','2017-09-21 13:52:33','2017-09-21 13:52:33','f6721351-1d27-44be-8d87-458eb85d4e4e'),
	(13,1,'58ba8b1875a626c83ca9d1afad45f77d7d70f0f8czozMjoid005emxvZVpIWjdwVVpabHRja2lTWjF1Snd4dFFxT0EiOw==','2017-09-21 13:52:36','2017-09-21 13:52:36','7e26450a-ffbd-4050-86e4-dfee6a86f8f5'),
	(14,1,'abfb78e111a56fd299a86e67df2b41de42fddfa5czozMjoic2QxNjNkaUpaTUhpd1ByQ1lQWnRhMGV5emd2d2h+ZEIiOw==','2017-09-25 17:27:56','2017-09-25 17:27:56','52c391f6-15da-4a6b-b5bb-c277cf3ac3fc'),
	(15,1,'fbcacb9c5ac853796d14cd30bfdab09aed2f5536czozMjoiRFhBN1pCTXV3d3V5RDQ1Sn5RV1g0YTNKWWM3RWRCOEEiOw==','2017-09-25 17:28:00','2017-09-25 17:28:00','36442673-1971-4e5e-9c3d-f2854fd6006d'),
	(16,1,'94bc9d1e482cad994f865849026a8c7361442b31czozMjoicTdnZWtVbUJ2OHd3dkZpeWxxQXRjMjNIaFZDbk1pY3ciOw==','2017-09-29 14:40:15','2017-09-29 14:40:15','296ca594-f95f-42ef-a853-4e87cc2b081c'),
	(17,1,'29dd8538549ff1cc85c47a795c62eab72eeec336czozMjoiYW5fUktxM204Q3k1YkhtTUZKQm4xaFdWNURvT1lCbTAiOw==','2017-10-02 14:24:50','2017-10-02 14:24:50','9fa9b9b3-be64-4e8f-93d2-c490e27a3989'),
	(20,1,'97fc639f58436863f616f02cbc301d7fdb315db4czozMjoiNjdFTEU1REtRTkF+QXZvV0RHN0p6akdWSHYzRERGcTIiOw==','2017-10-02 15:15:27','2017-10-02 15:15:27','aa1be1d1-7ea7-4a81-bbba-15d8967cc17e'),
	(21,1,'11ed9f12d67f1d2e517d76b6fdf2936b9d7286e1czozMjoiQXVXRDBuRGhhQUpWNnNQcjkzS0lab2FaY01scXNZWjYiOw==','2017-10-02 15:17:24','2017-10-02 15:17:24','e0e9b063-6fed-43e7-abf5-6612cc6570e3');

/*!40000 ALTER TABLE `craft_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_shunnedmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_shunnedmessages`;

CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `craft_shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_structureelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structureelements`;

CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `craft_structureelements_root_idx` (`root`),
  KEY `craft_structureelements_lft_idx` (`lft`),
  KEY `craft_structureelements_rgt_idx` (`rgt`),
  KEY `craft_structureelements_level_idx` (`level`),
  KEY `craft_structureelements_elementId_fk` (`elementId`),
  CONSTRAINT `craft_structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_structureelements` WRITE;
/*!40000 ALTER TABLE `craft_structureelements` DISABLE KEYS */;

INSERT INTO `craft_structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,NULL,1,1,10,0,'2017-09-13 17:22:55','2017-09-13 17:22:55','8c97a0c2-fc53-491a-8931-d3ae937498ab'),
	(2,1,8,1,2,3,1,'2017-09-13 17:22:55','2017-09-13 17:22:55','2d060851-17df-4e98-983b-7f4bd01f67c3'),
	(3,1,12,1,4,5,1,'2017-09-14 00:39:27','2017-09-14 00:39:27','13ac841d-c726-401d-81c1-5e378e3cdf3c'),
	(4,1,31,1,6,7,1,'2017-09-14 20:33:33','2017-09-14 20:33:33','e5eab871-7c60-4e01-be27-c1d228c85876'),
	(5,1,41,1,8,9,1,'2017-09-14 20:55:42','2017-09-14 20:55:42','e8a553fb-24cb-4466-85ba-aeaac21f8818');

/*!40000 ALTER TABLE `craft_structureelements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structures`;

CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_structures` WRITE;
/*!40000 ALTER TABLE `craft_structures` DISABLE KEYS */;

INSERT INTO `craft_structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'2017-09-12 18:24:12','2017-09-14 14:13:04','bfd81c34-dd91-4f00-b1f0-12e5a41ce32f');

/*!40000 ALTER TABLE `craft_structures` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_systemsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_systemsettings`;

CREATE TABLE `craft_systemsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemsettings_category_unq_idx` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_systemsettings` WRITE;
/*!40000 ALTER TABLE `craft_systemsettings` DISABLE KEYS */;

INSERT INTO `craft_systemsettings` (`id`, `category`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'email','{\"protocol\":\"php\",\"emailAddress\":\"benjamin.modayil@viget.com\",\"senderName\":\"Silent Sentinels - Ben M. Build\"}','2017-09-11 21:31:11','2017-09-11 21:31:11','197f0b95-ed11-4050-89fa-cd4150b996ff');

/*!40000 ALTER TABLE `craft_systemsettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_taggroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_taggroups`;

CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_taggroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_taggroups_handle_unq_idx` (`handle`),
  KEY `craft_taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_taggroups` WRITE;
/*!40000 ALTER TABLE `craft_taggroups` DISABLE KEYS */;

INSERT INTO `craft_taggroups` (`id`, `name`, `handle`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Default','default',1,'2017-09-11 21:31:11','2017-09-11 21:31:11','ab7cf689-2415-4f49-9e37-abfd599954ee');

/*!40000 ALTER TABLE `craft_taggroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tags`;

CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tags_groupId_fk` (`groupId`),
  CONSTRAINT `craft_tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_tags_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_tasks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tasks`;

CREATE TABLE `craft_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `currentStep` int(11) unsigned DEFAULT NULL,
  `totalSteps` int(11) unsigned DEFAULT NULL,
  `status` enum('pending','error','running') COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` mediumtext COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tasks_root_idx` (`root`),
  KEY `craft_tasks_lft_idx` (`lft`),
  KEY `craft_tasks_rgt_idx` (`rgt`),
  KEY `craft_tasks_level_idx` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_templatecachecriteria
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecachecriteria`;

CREATE TABLE `craft_templatecachecriteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `criteria` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecachecriteria_cacheId_fk` (`cacheId`),
  KEY `craft_templatecachecriteria_type_idx` (`type`),
  CONSTRAINT `craft_templatecachecriteria_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_templatecacheelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecacheelements`;

CREATE TABLE `craft_templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `craft_templatecacheelements_cacheId_fk` (`cacheId`),
  KEY `craft_templatecacheelements_elementId_fk` (`elementId`),
  CONSTRAINT `craft_templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_templatecaches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecaches`;

CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecaches_expiryDate_cacheKey_locale_path_idx` (`expiryDate`,`cacheKey`,`locale`,`path`),
  KEY `craft_templatecaches_locale_fk` (`locale`),
  CONSTRAINT `craft_templatecaches_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tokens`;

CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `route` text COLLATE utf8_unicode_ci,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tokens_token_unq_idx` (`token`),
  KEY `craft_tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups`;

CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_usergroups_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_usergroups_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups_users`;

CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `craft_usergroups_users_userId_fk` (`userId`),
  CONSTRAINT `craft_usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_userpermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions`;

CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_userpermissions_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;

CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `craft_userpermissions_usergroups_groupId_fk` (`groupId`),
  CONSTRAINT `craft_userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_userpermissions_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_users`;

CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `craft_userpermissions_users_userId_fk` (`userId`),
  CONSTRAINT `craft_userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_users`;

CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preferredLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weekStartDay` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `client` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `suspended` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pending` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIPAddress` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(4) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `verificationCode` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_users_username_unq_idx` (`username`),
  UNIQUE KEY `craft_users_email_unq_idx` (`email`),
  KEY `craft_users_verificationCode_idx` (`verificationCode`),
  KEY `craft_users_uid_idx` (`uid`),
  KEY `craft_users_preferredLocale_fk` (`preferredLocale`),
  CONSTRAINT `craft_users_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_users_preferredLocale_fk` FOREIGN KEY (`preferredLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;

INSERT INTO `craft_users` (`id`, `username`, `photo`, `firstName`, `lastName`, `email`, `password`, `preferredLocale`, `weekStartDay`, `admin`, `client`, `locked`, `suspended`, `pending`, `archived`, `lastLoginDate`, `lastLoginAttemptIPAddress`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'benjamin.modayil',NULL,'','','benjamin.modayil@viget.com','$2y$13$9zBh6ah6cnwQMy8AC0Jyr.qHXqj7MVxIC6SQlOie/H5Q1tZzu192W',NULL,0,1,0,0,0,0,0,'2017-10-02 15:17:24','::1',NULL,NULL,'2017-09-15 19:24:48',NULL,NULL,NULL,NULL,0,'2017-10-02 15:17:04','2017-09-11 21:31:08','2017-10-02 15:17:24','dabc901c-7073-4b26-9acc-a6b7fed57b91');

/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_widgets`;

CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(4) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_widgets_userId_fk` (`userId`),
  CONSTRAINT `craft_widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;

INSERT INTO `craft_widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'RecentEntries',1,NULL,NULL,1,'2017-09-11 21:31:15','2017-09-11 21:31:15','3aa5c285-9f64-4787-adfb-59e0573da138'),
	(2,1,'GetHelp',2,NULL,NULL,1,'2017-09-11 21:31:15','2017-09-11 21:31:15','a03115ab-b951-4cd3-8424-b482c1cf9a18'),
	(3,1,'Updates',3,NULL,NULL,1,'2017-09-11 21:31:15','2017-09-11 21:31:15','252ceb07-5a9a-46fd-badf-4f30cd961666'),
	(4,1,'Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\"}',1,'2017-09-11 21:31:15','2017-09-11 21:31:15','2256fc74-dbc5-4faf-9a99-1ee838a77857');

/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
