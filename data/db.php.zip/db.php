<?php 
{
    return array(
    'server' => 'localhost',
    'user' => 'root',
    'password' => 'root',
    'database' => 'craft_db',
    'tablePrefix' => 'craft'
    );
}